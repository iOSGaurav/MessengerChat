# VPAT® / Accessibility Conformance Report (WCAG) – Template

> This is a simplified VPAT-style template oriented around WCAG criteria for mobile apps.  
> Replace all **TBD** fields and remove sections that do not apply.

---

## Product information
- Product name: **TBD**
- Version: **TBD**
- Vendor/company: **TBD**
- Platforms: **Android / iOS**
- Report date: **TBD**
- Contact: **TBD**

## Evaluation methods
Describe how you evaluated accessibility (manual + automated):
- Screen reader testing: **TalkBack / VoiceOver**
- Automated audits: **Appium-based metadata checks**
- Color contrast: **TBD (tool/method)**
- Devices/OS versions: **TBD**

## Terms
- Supports
- Partially Supports
- Does Not Support
- Not Applicable

---

## WCAG 2.2 Conformance Table (fill in)

| Criteria | Conformance | Remarks / explanations |
|---|---|---|
| 1.1.1 Non-text Content | TBD | TBD |
| 1.3.1 Info and Relationships | TBD | TBD |
| 1.3.2 Meaningful Sequence | TBD | TBD |
| 1.4.1 Use of Color | TBD | TBD |
| 1.4.3 Contrast (Minimum) | TBD | TBD |
| 1.4.11 Non-text Contrast | TBD | TBD |
| 2.1.1 Keyboard | TBD | TBD |
| 2.4.3 Focus Order | TBD | TBD |
| 2.4.7 Focus Visible | TBD | TBD |
| 2.5.8 Target Size (Minimum) | TBD | TBD |
| 3.3.1 Error Identification | TBD | TBD |
| 3.3.2 Labels or Instructions | TBD | TBD |
| 4.1.2 Name, Role, Value | TBD | TBD |

---

## Notes / Exceptions
- TBD

## Roadmap / Remediation plan
- TBD
