import { expect } from "chai";
import { remote } from "webdriverio";

describe("iOS smoke + accessibility snapshot", function () {
  this.timeout(300000);

  it("launches app and finds at least one element", async () => {
    const server = process.env.APPIUM_SERVER || "http://127.0.0.1:4723/wd/hub";

    const caps = {
      platformName: "iOS",
      "appium:automationName": process.env.IOS_AUTOMATION_NAME || "XCUITest",
      "appium:deviceName": process.env.IOS_DEVICE_NAME || "iPhone 15",
      "appium:newCommandTimeout": 120,
    };

    if (process.env.IOS_APP) caps["appium:app"] = process.env.IOS_APP;
    if (process.env.IOS_BUNDLE_ID) caps["appium:bundleId"] = process.env.IOS_BUNDLE_ID;

    const driver = await remote({
      hostname: new URL(server).hostname,
      port: Number(new URL(server).port || 4723),
      path: new URL(server).pathname,
      logLevel: "error",
      capabilities: caps,
    });

    try {
      await driver.pause(2000);
      const els = await driver.$$("//*[@visible='true' or @hittable='true' or string-length(@label)>0]");
      expect(els.length).to.be.greaterThan(0);
    } finally {
      await driver.deleteSession();
    }
  });
});
