import { expect } from "chai";
import { remote } from "webdriverio";

describe("Android smoke + accessibility snapshot", function () {
  this.timeout(300000);

  it("launches app and finds at least one element", async () => {
    const server = process.env.APPIUM_SERVER || "http://127.0.0.1:4723/wd/hub";

    const caps = {
      platformName: "Android",
      "appium:automationName": process.env.ANDROID_AUTOMATION_NAME || "UiAutomator2",
      "appium:deviceName": process.env.ANDROID_DEVICE_NAME || "Android Emulator",
      "appium:newCommandTimeout": 120,
      "appium:autoGrantPermissions": true,
    };

    if (process.env.ANDROID_APP) caps["appium:app"] = process.env.ANDROID_APP;
    if (process.env.ANDROID_APP_PACKAGE) caps["appium:appPackage"] = process.env.ANDROID_APP_PACKAGE;
    if (process.env.ANDROID_APP_ACTIVITY) caps["appium:appActivity"] = process.env.ANDROID_APP_ACTIVITY;

    const driver = await remote({
      hostname: new URL(server).hostname,
      port: Number(new URL(server).port || 4723),
      path: new URL(server).pathname,
      logLevel: "error",
      capabilities: caps,
    });

    try {
      await driver.pause(2000);
      const els = await driver.$$("//*[@clickable='true' or string-length(@text)>0 or string-length(@content-desc)>0]");
      expect(els.length).to.be.greaterThan(0);
    } finally {
      await driver.deleteSession();
    }
  });
});
