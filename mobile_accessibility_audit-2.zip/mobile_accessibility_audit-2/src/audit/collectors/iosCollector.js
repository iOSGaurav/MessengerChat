import { safeStr } from "../utils.js";

/**
 * Collects a snapshot of visible elements on iOS (XCUITest).
 * Strategy:
 *  - Query elements that are hittable or have labels.
 *  - Collect:
 *      name, label, value, type, rect, enabled, displayed/hittable
 */
export async function collectIosSnapshot(driver) {
  // iOS element tree can be huge. Keep scope on likely user-facing items.
  const xpath =
    "//*[" +
    "@visible='true' or @hittable='true' or string-length(@label)>0 or string-length(@name)>0" +
    "]";

  const elements = await driver.$$(xpath);
  const items = [];
  for (const el of elements) {
    try {
      const rect = await el.getRect();
      const displayed = await el.isDisplayed().catch(() => true);
      const enabled = await el.isEnabled().catch(() => true);

      const name = await el.getAttribute("name").catch(() => "");
      const label = await el.getAttribute("label").catch(() => "");
      const value = await el.getAttribute("value").catch(() => "");
      const type = await el.getAttribute("type").catch(() => "");

      const accessibilityId = safeStr(name); // often equals accessibilityIdentifier
      items.push({
        platform: "ios",
        rect,
        displayed,
        enabled,
        type: safeStr(type),
        name: safeStr(name),
        label: safeStr(label),
        value: safeStr(value),
        accessibilityId,
      });
    } catch {
      // ignore element read failures
    }
  }
  return items;
}
