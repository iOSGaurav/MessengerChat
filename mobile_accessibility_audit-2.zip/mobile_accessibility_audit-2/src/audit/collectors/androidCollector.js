import { safeStr } from "../utils.js";

/**
 * Collects a snapshot of visible elements on Android (UiAutomator2).
 * Strategy:
 *  - Grab all elements matching XPath for clickable, focusable, or with text/content-desc.
 *  - For each element, collect:
 *      text, content-desc, resource-id, class, bounds/rect, clickable, enabled, displayed
 */
export async function collectAndroidSnapshot(driver) {
  // A broad XPath is used intentionally to catch most interactive + readable content.
  const xpath =
    "//*[" +
    "@clickable='true' or @focusable='true' or @checkable='true' or " +
    "string-length(@text)>0 or string-length(@content-desc)>0" +
    "]";

  const elements = await driver.$$(xpath);
  const items = [];
  for (const el of elements) {
    try {
      const rect = await el.getRect();
      const displayed = await el.isDisplayed().catch(() => true);
      const enabled = await el.isEnabled().catch(() => true);

      const text = await el.getAttribute("text").catch(() => "");
      const contentDesc = await el.getAttribute("content-desc").catch(() => "");
      const resourceId = await el.getAttribute("resource-id").catch(() => "");
      const className = await el.getAttribute("class").catch(() => "");
      const clickable = await el.getAttribute("clickable").catch(() => "");
      const focusable = await el.getAttribute("focusable").catch(() => "");

      // Prefer accessibilityId as content-desc in Android
      const accessibilityId = safeStr(contentDesc);

      items.push({
        platform: "android",
        rect,
        displayed,
        enabled,
        clickable: String(clickable) === "true",
        focusable: String(focusable) === "true",
        className: safeStr(className),
        text: safeStr(text),
        contentDesc: safeStr(contentDesc),
        resourceId: safeStr(resourceId),
        accessibilityId,
      });
    } catch {
      // ignore element read failures
    }
  }
  return items;
}
