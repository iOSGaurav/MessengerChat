export const Severity = {
  BLOCKER: "blocker",
  HIGH: "high",
  MEDIUM: "medium",
  LOW: "low",
  INFO: "info",
};

export const severityRank = {
  blocker: 5,
  high: 4,
  medium: 3,
  low: 2,
  info: 1,
};
