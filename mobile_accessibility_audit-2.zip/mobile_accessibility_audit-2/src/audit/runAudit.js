import { RULES } from "./rules/index.js";
import { nowIso } from "./utils.js";
import { severityRank } from "./severity.js";

export function runAudit({ platform, appInfo, snapshot }) {
  const startedAt = nowIso();
  let issues = [];
  for (const rule of RULES) {
    try {
      const found = rule(snapshot) || [];
      issues = issues.concat(found);
    } catch (e) {
      issues.push({
        ruleId: "audit_rule_error",
        title: "Audit rule error",
        severity: "info",
        wcag: { id: "N/A", title: "N/A" },
        element: { platform, rect: null, hint: String(rule?.name || "unknown") },
        details: `Rule threw an exception: ${String(e?.message || e)}`,
      });
    }
  }

  issues.sort((a, b) => (severityRank[b.severity] || 0) - (severityRank[a.severity] || 0));

  const summary = issues.reduce((acc, it) => {
    acc.total += 1;
    acc.bySeverity[it.severity] = (acc.bySeverity[it.severity] || 0) + 1;
    return acc;
  }, { total: 0, bySeverity: {} });

  return {
    meta: {
      tool: "mobile_accessibility_audit",
      version: "1.0.0",
      platform,
      startedAt,
      finishedAt: nowIso(),
    },
    app: appInfo,
    summary,
    issues,
  };
}
