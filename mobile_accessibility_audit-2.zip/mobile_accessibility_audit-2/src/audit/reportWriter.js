import fs from "node:fs";
import path from "node:path";

export function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

export function writeJson(filePath, data) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
}

export function writeText(filePath, text) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, text, "utf-8");
}

export function toMarkdownReport(audit) {
  const { meta, app, summary, issues } = audit;

  const lines = [];
  lines.push(`# Mobile Accessibility Audit (${meta.platform})`);
  lines.push(``);
  lines.push(`- **Generated:** ${meta.finishedAt}`);
  lines.push(`- **App:** ${app?.name || "Unknown"} ${app?.version || ""}`.trim());
  lines.push(`- **Bundle/Package:** ${app?.bundleId || app?.packageName || "Unknown"}`);
  lines.push(``);
  lines.push(`## Summary`);
  lines.push(`- Total issues: **${summary.total}**`);
  for (const [sev, count] of Object.entries(summary.bySeverity)) {
    lines.push(`- ${sev}: **${count}**`);
  }
  lines.push(``);
  lines.push(`## Issues`);
  issues.forEach((it, idx) => {
    lines.push(`### ${idx + 1}. ${it.title} (${it.severity})`);
    lines.push(`- **Rule:** \`${it.ruleId}\``);
    lines.push(`- **WCAG:** ${it.wcag?.id || "N/A"} – ${it.wcag?.title || ""}`.trim());
    lines.push(`- **Element:** ${it.element?.hint || ""}`);
    if (it.element?.rect) {
      const r = it.element.rect;
      lines.push(`- **Bounds:** x=${r.x}, y=${r.y}, w=${r.width}, h=${r.height}`);
    }
    lines.push(`- **Details:** ${it.details}`);
    if (it.related?.length) {
      lines.push(`- **Related:**`);
      for (const rel of it.related) {
        lines.push(`  - ${rel.hint} (x=${rel.rect?.x}, y=${rel.rect?.y}, w=${rel.rect?.width}, h=${rel.rect?.height})`);
      }
    }
    lines.push(``);
  });

  return lines.join("\n");
}
