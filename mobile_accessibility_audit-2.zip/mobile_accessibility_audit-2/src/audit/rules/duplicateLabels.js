import { Severity } from "../severity.js";
import { WCAG } from "../wcagMap.js";
import { normalizeLabel, isBlank, fmtSelectorHint } from "../utils.js";

/**
 * Rule: Avoid multiple interactive elements with the exact same accessible name in the same view,
 * unless their role/context is clear (e.g., list items with the same label is usually bad).
 */
export function ruleDuplicateLabels(snapshot) {
  const issues = [];
  const labelMap = new Map();

  for (const el of snapshot) {
    const isInteractive = el.clickable || el.focusable || el.type?.includes("Button") || el.type?.includes("TextField");
    if (!isInteractive) continue;

    const raw =
      el.platform === "android"
        ? (el.contentDesc || el.text)
        : (el.label || el.name);

    if (isBlank(raw)) continue;
    const key = normalizeLabel(raw);
    if (!labelMap.has(key)) labelMap.set(key, []);
    labelMap.get(key).push(el);
  }

  for (const [key, els] of labelMap.entries()) {
    if (els.length < 2) continue;

    // only flag if at least two are within same rough area; basic heuristic
    issues.push({
      ruleId: "duplicate_accessible_name",
      title: "Duplicate accessible names for multiple controls",
      severity: Severity.LOW,
      wcag: WCAG.DUPLICATE_LABEL,
      element: {
        platform: els[0].platform,
        hint: els.slice(0, 3).map(fmtSelectorHint).join(" / "),
        rect: els[0].rect,
      },
      details: `Multiple controls share the accessible name "${key}". Consider making labels unique (e.g., include context like item name, position, or action).`,
      related: els.slice(0, 10).map(e => ({
        rect: e.rect,
        hint: fmtSelectorHint(e),
      })),
    });
  }

  return issues;
}
