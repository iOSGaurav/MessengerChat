import { Severity } from "../severity.js";
import { WCAG } from "../wcagMap.js";
import { fmtSelectorHint, isBlank } from "../utils.js";

/**
 * iOS-specific: For text fields/switches/sliders, value should be meaningful.
 */
export function ruleIosValue(snapshot) {
  const issues = [];
  for (const el of snapshot) {
    if (el.platform !== "ios") continue;
    const isField = (el.type || "").includes("TextField") || (el.type || "").includes("SecureTextField") || (el.type || "").includes("Switch") || (el.type || "").includes("Slider");
    if (!isField) continue;

    if (isBlank(el.label) && isBlank(el.name)) continue; // already handled by label rule

    // Value can be empty for empty text fields - that's OK; but for switches/sliders it shouldn't be empty
    const isToggle = (el.type || "").includes("Switch") || (el.type || "").includes("Slider");
    if (isToggle && isBlank(el.value)) {
      issues.push({
        ruleId: "missing_control_value",
        title: "Control value not exposed",
        severity: Severity.MEDIUM,
        wcag: WCAG.VALUE,
        element: { platform: "ios", rect: el.rect, hint: fmtSelectorHint(el) },
        details: "VoiceOver should announce current value/state for toggles and sliders. Ensure accessibilityValue reflects the state.",
      });
    }
  }
  return issues;
}
