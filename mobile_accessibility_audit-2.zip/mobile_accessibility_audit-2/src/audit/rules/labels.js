import { Severity } from "../severity.js";
import { WCAG } from "../wcagMap.js";
import { isBlank, fmtSelectorHint } from "../utils.js";

/**
 * Rule: Interactive elements should have an accessible name.
 * Android: content-desc OR text should exist for clickable/focusable controls.
 * iOS: label OR name should exist for controls.
 */
export function ruleLabels(snapshot) {
  const issues = [];

  for (const el of snapshot) {
    const isInteractive = el.clickable || el.focusable || el.type?.includes("Button") || el.type?.includes("TextField");
    if (!isInteractive) continue;

    const name =
      el.platform === "android"
        ? (el.contentDesc || el.text)
        : (el.label || el.name);

    if (isBlank(name)) {
      issues.push({
        ruleId: "missing_accessible_name",
        title: "Missing accessible name",
        severity: Severity.HIGH,
        wcag: WCAG.LABELS,
        element: {
          rect: el.rect,
          hint: fmtSelectorHint(el),
          platform: el.platform,
        },
        details:
          "Screen readers announce controls using their accessible name. Add a meaningful label (Android: contentDescription; iOS: accessibilityLabel) or ensure visible text is exposed.",
      });
    }
  }
  return issues;
}
