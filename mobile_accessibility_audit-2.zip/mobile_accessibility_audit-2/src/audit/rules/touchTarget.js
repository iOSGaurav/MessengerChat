import { Severity } from "../severity.js";
import { WCAG } from "../wcagMap.js";
import { fmtSelectorHint } from "../utils.js";

/**
 * Rule: Touch target size should be >= 44x44pt (iOS) or 48x48dp (Android).
 * We'll use 44 for iOS and 48 for Android as minimum.
 */
export function ruleTouchTarget(snapshot) {
  const issues = [];
  for (const el of snapshot) {
    const isInteractive = el.clickable || el.focusable || el.type?.includes("Button") || el.type?.includes("TextField");
    if (!isInteractive) continue;

    const min = el.platform === "ios" ? 44 : 48;
    const w = el.rect?.width ?? 0;
    const h = el.rect?.height ?? 0;

    if (w > 0 && h > 0 && (w < min || h < min)) {
      issues.push({
        ruleId: "touch_target_too_small",
        title: "Touch target too small",
        severity: Severity.MEDIUM,
        wcag: WCAG.TOUCH_TARGET,
        element: {
          rect: el.rect,
          hint: fmtSelectorHint(el),
          platform: el.platform,
        },
        details: `Interactive elements should be at least ${min}x${min} (platform minimum). Increase hit area using padding, container button, or accessibilityHitTest.`,
      });
    }
  }
  return issues;
}
