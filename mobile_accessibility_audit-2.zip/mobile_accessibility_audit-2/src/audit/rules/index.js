import { ruleLabels } from "./labels.js";
import { ruleTouchTarget } from "./touchTarget.js";
import { ruleDuplicateLabels } from "./duplicateLabels.js";
import { ruleIosValue } from "./iosValueHint.js";

export const RULES = [
  ruleLabels,
  ruleTouchTarget,
  ruleDuplicateLabels,
  ruleIosValue,
];
