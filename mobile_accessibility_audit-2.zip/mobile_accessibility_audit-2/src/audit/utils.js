export function safeStr(v) {
  return (v === null || v === undefined) ? "" : String(v);
}

export function isBlank(s) {
  return safeStr(s).trim().length === 0;
}

export function uniq(arr) {
  return [...new Set(arr)];
}

export function nowIso() {
  return new Date().toISOString();
}

export function pxToDp(px, devicePixelRatio = 1) {
  // rough heuristic for Android; Appium rects are already dp-like for many devices
  return px / devicePixelRatio;
}

export function area(rect) {
  return Math.max(0, rect.width) * Math.max(0, rect.height);
}

export function fmtSelectorHint(el) {
  const hints = [];
  if (el.accessibilityId) hints.push(`accessibilityId=${el.accessibilityId}`);
  if (el.resourceId) hints.push(`resourceId=${el.resourceId}`);
  if (el.name) hints.push(`name=${el.name}`);
  if (el.label) hints.push(`label=${el.label}`);
  if (el.text) hints.push(`text=${el.text}`);
  return hints.slice(0, 3).join(" | ");
}

export function normalizeLabel(s) {
  return safeStr(s).trim().replace(/\s+/g, " ").toLowerCase();
}
