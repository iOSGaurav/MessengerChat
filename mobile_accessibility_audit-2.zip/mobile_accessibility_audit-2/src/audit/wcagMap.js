export const WCAG = {
  LABELS: { id: "1.3.1/4.1.2", title: "Info and Relationships / Name, Role, Value" },
  TOUCH_TARGET: { id: "2.5.8", title: "Target Size (Minimum)" },
  DUPLICATE_LABEL: { id: "3.3.2/4.1.2", title: "Labels or Instructions / Name, Role, Value" },
  HINTS: { id: "3.3.2", title: "Labels or Instructions" },
  VALUE: { id: "4.1.2", title: "Name, Role, Value" },
};
