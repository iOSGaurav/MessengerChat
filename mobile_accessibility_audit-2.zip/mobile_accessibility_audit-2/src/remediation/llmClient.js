/**
 * Optional LLM integration stub.
 *
 * If you want AI-generated remediation with your own model/provider:
 * 1) Implement `createRemediationWithLLM(audit)` below
 * 2) Set USE_LLM=true in your environment
 *
 * Keep secrets out of git and use .env.
 */
export async function createRemediationWithLLM(_audit) {
  throw new Error("LLM client not configured. Implement createRemediationWithLLM() in src/remediation/llmClient.js");
}
