import { draftRemediationDoc } from "./heuristics.js";
import { createRemediationWithLLM } from "./llmClient.js";

export async function generateRemediation(audit) {
  const useLLM = String(process.env.USE_LLM || "").toLowerCase() === "true";
  if (useLLM) {
    return await createRemediationWithLLM(audit);
  }
  return draftRemediationDoc(audit);
}
