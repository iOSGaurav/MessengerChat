import { normalizeLabel } from "../audit/utils.js";

export function generateFixSuggestions(issue) {
  const suggestions = [];

  switch (issue.ruleId) {
    case "missing_accessible_name":
      suggestions.push(
        "Expose a meaningful accessible name.",
        "- Android: set `android:contentDescription` (or ensure visible text is exposed) and avoid redundant announcements.",
        "- iOS: set `accessibilityLabel` / `accessibilityIdentifier` as appropriate.",
        "Prefer action-oriented names for buttons (e.g., 'Save', 'Add to cart').",
      );
      break;

    case "touch_target_too_small":
      suggestions.push(
        "Increase the hit target without changing visuals:",
        "- Wrap the icon in a larger container button.",
        "- Add padding/margin around tappable area.",
        "- Use `hitSlop` (React Native) or `contentShape` (SwiftUI) / `minimumTouchTarget` patterns.",
      );
      break;

    case "duplicate_accessible_name":
      suggestions.push(
        "Make names unique by adding context:",
        "- Include the associated content (e.g., 'Remove item: Apples').",
        "- Include position (e.g., 'Step 2 of 5').",
        "- For repeated icons, use `accessibilityLabel` + `accessibilityHint`.",
      );
      break;

    case "missing_control_value":
      suggestions.push(
        "Expose state/value for controls:",
        "- iOS: set `accessibilityValue` for switches/sliders ('On'/'Off', '50%').",
        "- Ensure the control is a native UI control or correctly mapped semantic role.",
      );
      break;

    default:
      suggestions.push("Review the element and ensure it is correctly exposed to TalkBack/VoiceOver.");
  }

  return suggestions;
}

export function draftRemediationDoc(audit) {
  const lines = [];
  lines.push(`# Remediation Suggestions (${audit.meta.platform})`);
  lines.push(``);
  lines.push(`Generated from audit: ${audit.meta.finishedAt}`);
  lines.push(``);
  audit.issues.forEach((issue, idx) => {
    lines.push(`## ${idx + 1}. ${issue.title} (${issue.severity})`);
    lines.push(`- Rule: \`${issue.ruleId}\``);
    lines.push(`- WCAG: ${issue.wcag?.id || "N/A"} – ${issue.wcag?.title || ""}`.trim());
    lines.push(`- Element: ${issue.element?.hint || ""}`);
    lines.push(``);
    for (const s of generateFixSuggestions(issue)) lines.push(`- ${s}`);
    lines.push(``);
  });
  return lines.join("\n");
}

// Utility for grouping
export function groupByRule(audit) {
  const map = new Map();
  for (const it of audit.issues) {
    if (!map.has(it.ruleId)) map.set(it.ruleId, []);
    map.get(it.ruleId).push(it);
  }
  return map;
}
