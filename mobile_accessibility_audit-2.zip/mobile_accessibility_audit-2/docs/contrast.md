# Contrast testing (manual / external tooling)

Automated contrast checking is not implemented in this repo by default.

## Recommended approaches
1. **Design tokens / theming audit**
   - Export colors from design system
   - Verify contrast ratios for text and key UI states

2. **Screenshot sampling**
   - Capture screenshots for key screens + states
   - Use contrast tools to sample foreground/background pairs

3. **In-app debug overlay**
   - If you control the app code, add a debug overlay to display computed colors and contrast ratios.

## Suggested deliverable
Include:
- A list of screens checked
- Failing pairs and their ratios
- Remediation plan (token changes or component updates)
