# WCAG mapping notes for mobile apps

This toolkit focuses on **WCAG 2.2** criteria most commonly applicable to mobile UI.

## Common criteria for mobile apps
- **1.1.1 Non-text Content**: icons need labels/alt text
- **1.3.1 Info and Relationships**: correct grouping, labels for inputs
- **1.4.3 / 1.4.11 Contrast**: text and non-text contrast (manual or separate tooling)
- **2.1.1 Keyboard**: for external keyboards/switch control
- **2.4.3 Focus Order**: logical navigation order (manual)
- **2.5.8 Target Size (Minimum)**: touch target size
- **3.3.1 / 3.3.2 Errors + labels**: input errors, instructions
- **4.1.2 Name, Role, Value**: exposed semantics for assistive tech

## Why some items are manual
- Focus order depends on runtime tree, custom views, and navigation containers
- Contrast needs pixel sampling or design token analysis
- Captions/audio descriptions depend on media content
