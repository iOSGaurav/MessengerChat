# Manual Screen Reader Checklist (TalkBack + VoiceOver)

Automated checks help you catch metadata issues, but a **manual pass** is required for:
- Focus order
- Announcements (live regions / alerts)
- Custom gestures / rotors
- Keyboard/external switch access (if relevant)

---

## TalkBack (Android) – quick checklist

### Setup
1. Settings → Accessibility → **TalkBack** → On
2. TalkBack tutorial: complete once on a test device

### Core checks (per screen)
- **Explore by touch** reads correct labels (not “button, button”)
- **Swipe navigation** follows a logical order (top-to-bottom, left-to-right)
- All actionable elements:
  - Are reachable
  - Have meaningful names
  - Announce role/state (checkbox checked/unchecked, switch on/off)
- **Text fields**
  - Label announced (not placeholder-only)
  - Errors announced and programmatically associated
- **Dialogs / bottom sheets**
  - Focus moves into the dialog
  - Can dismiss without “trapping” focus
- **Lists**
  - Each row announces enough context (title + secondary info + actions)
  - Action icons have unique labels (“Remove item: X”)
- **Dynamic updates**
  - Success/error toasts announced (use `accessibilityLiveRegion` or announcements)

---

## VoiceOver (iOS) – quick checklist

### Setup
1. Settings → Accessibility → **VoiceOver** → On
2. Rotor: understand how it changes navigation

### Core checks (per screen)
- Swipe navigation has logical order
- Controls announce:
  - Name
  - Role
  - Value/state (switch on/off, slider %, selected/unselected)
- **Buttons**
  - Use concise action verbs
- **Text fields**
  - Label is announced (not placeholder-only)
  - Errors announced and associated
- **Modal screens**
  - Focus moves into modal; background is not reachable unless intended
- **Custom controls**
  - Use correct traits (`.button`, `.selected`, etc.)
- **Announcements**
  - Important updates announced via `UIAccessibility.post(notification: .announcement, ...)`

---

## Record findings
Capture:
- Device + OS version
- Screen name and steps
- Expected vs actual
- Screenshot/screen recording
