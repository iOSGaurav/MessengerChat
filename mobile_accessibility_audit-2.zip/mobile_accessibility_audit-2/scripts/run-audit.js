#!/usr/bin/env node
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { Command } from "commander";
import { remote } from "webdriverio";
import { collectAndroidSnapshot } from "../src/audit/collectors/androidCollector.js";
import { collectIosSnapshot } from "../src/audit/collectors/iosCollector.js";
import { runAudit } from "../src/audit/runAudit.js";
import { writeJson, writeText, toMarkdownReport } from "../src/audit/reportWriter.js";
import { generateRemediation } from "../src/remediation/index.js";

const program = new Command();

program
  .requiredOption("--platform <platform>", "android or ios")
  .option("--name <name>", "app name", "YourApp")
  .option("--version <version>", "app version", "0.0.0");

program.parse(process.argv);
const opts = program.opts();

const platform = opts.platform.toLowerCase();
if (!["android", "ios"].includes(platform)) {
  console.error("platform must be android or ios");
  process.exit(2);
}

const server = process.env.APPIUM_SERVER || "http://127.0.0.1:4723/wd/hub";

function androidCaps() {
  const app = process.env.ANDROID_APP;
  const appPackage = process.env.ANDROID_APP_PACKAGE;
  const appActivity = process.env.ANDROID_APP_ACTIVITY;

  const caps = {
    platformName: "Android",
    "appium:automationName": process.env.ANDROID_AUTOMATION_NAME || "UiAutomator2",
    "appium:deviceName": process.env.ANDROID_DEVICE_NAME || "Android Emulator",
    "appium:newCommandTimeout": 120,
    "appium:autoGrantPermissions": true,
  };

  if (app && fs.existsSync(app)) caps["appium:app"] = path.resolve(app);
  if (appPackage) caps["appium:appPackage"] = appPackage;
  if (appActivity) caps["appium:appActivity"] = appActivity;

  return caps;
}

function iosCaps() {
  const app = process.env.IOS_APP;
  const bundleId = process.env.IOS_BUNDLE_ID;

  const caps = {
    platformName: "iOS",
    "appium:automationName": process.env.IOS_AUTOMATION_NAME || "XCUITest",
    "appium:deviceName": process.env.IOS_DEVICE_NAME || "iPhone 15",
    "appium:newCommandTimeout": 120,
  };

  if (app && fs.existsSync(app)) caps["appium:app"] = path.resolve(app);
  if (bundleId) caps["appium:bundleId"] = bundleId;

  return caps;
}

const caps = platform === "android" ? androidCaps() : iosCaps();

const connection = {
  hostname: new URL(server).hostname,
  port: Number(new URL(server).port || 4723),
  path: new URL(server).pathname,
  logLevel: "error",
  capabilities: caps,
};

const outDir = path.resolve("reports", platform);

let driver;
try {
  driver = await remote(connection);

  // Basic stabilization
  await driver.pause(2500);

  const appInfo = {
    name: opts.name,
    version: opts.version,
    packageName: process.env.ANDROID_APP_PACKAGE || null,
    bundleId: process.env.IOS_BUNDLE_ID || null,
  };

  const snapshot = platform === "android"
    ? await collectAndroidSnapshot(driver)
    : await collectIosSnapshot(driver);

  const audit = runAudit({ platform, appInfo, snapshot });

  const auditJson = path.join(outDir, "audit.json");
  const auditMd = path.join(outDir, "audit.md");
  writeJson(auditJson, audit);
  writeText(auditMd, toMarkdownReport(audit));

  const remediationMd = path.join(outDir, "remediation.md");
  const remediation = await generateRemediation(audit);
  writeText(remediationMd, remediation);

  console.log(`✅ Audit complete:
- ${auditJson}
- ${auditMd}
- ${remediationMd}`);
} catch (e) {
  console.error("Audit failed:", e?.message || e);
  process.exitCode = 1;
} finally {
  if (driver) {
    try { await driver.deleteSession(); } catch {}
  }
}
