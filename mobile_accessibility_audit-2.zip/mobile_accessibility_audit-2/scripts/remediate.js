#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { Command } from "commander";
import { generateRemediation } from "../src/remediation/index.js";

const program = new Command();
program
  .requiredOption("--input <file>", "audit json file")
  .option("--output <file>", "output markdown file (default: alongside input)");

program.parse(process.argv);
const { input, output } = program.opts();

const audit = JSON.parse(fs.readFileSync(input, "utf-8"));
const md = await generateRemediation(audit);

const out = output || path.join(path.dirname(input), "remediation.md");
fs.writeFileSync(out, md, "utf-8");
console.log(`✅ Remediation written to ${out}`);
