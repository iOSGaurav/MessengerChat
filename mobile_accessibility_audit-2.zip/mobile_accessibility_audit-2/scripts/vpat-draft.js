#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { Command } from "commander";

const program = new Command();
program
  .requiredOption("--input <file>", "audit json file")
  .requiredOption("--output <file>", "output markdown file");

program.parse(process.argv);
const { input, output } = program.opts();

const audit = JSON.parse(fs.readFileSync(input, "utf-8"));

const wcagBuckets = new Map();
for (const issue of audit.issues) {
  const key = issue.wcag?.id || "N/A";
  if (!wcagBuckets.has(key)) wcagBuckets.set(key, []);
  wcagBuckets.get(key).push(issue);
}

const lines = [];
lines.push(`# VPAT Draft (WCAG) – ${audit.meta.platform}`);
lines.push(``);
lines.push(`Generated: ${audit.meta.finishedAt}`);
lines.push(``);
lines.push(`> This is a *draft* generated from automated findings. It must be validated and completed by a human reviewer.`);
lines.push(``);
lines.push(`## Product information`);
lines.push(`- Product name: ${audit.app?.name || "TBD"}`);
lines.push(`- Version: ${audit.app?.version || "TBD"}`);
lines.push(`- Platform: ${audit.meta.platform}`);
lines.push(``);
lines.push(`## Summary of automated findings`);
lines.push(`- Total issues: ${audit.summary.total}`);
for (const [sev, count] of Object.entries(audit.summary.bySeverity || {})) {
  lines.push(`- ${sev}: ${count}`);
}
lines.push(``);
lines.push(`## WCAG criteria (auto-derived)`);
lines.push(``);
lines.push(`| WCAG | Support level | Notes / Findings |`);
lines.push(`|---|---|---|`);

for (const [wcagId, issues] of wcagBuckets.entries()) {
  const titles = [...new Set(issues.map(i => i.title))].slice(0, 3).join("; ");
  const support = issues.some(i => ["blocker","high"].includes(i.severity)) ? "Partially Supports" : "Supports with Exceptions";
  lines.push(`| ${wcagId} | ${support} | ${titles} (see audit report) |`);
}

lines.push(``);
lines.push(`## Manual test requirements`);
lines.push(`- Screen reader navigation (TalkBack/VoiceOver) focus order and announcements`);
lines.push(`- Color contrast (text and non-text)`);
lines.push(`- Captions / audio descriptions (if media present)`);
lines.push(`- Dynamic content announcements and error handling`);
lines.push(``);

fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, lines.join("\n"), "utf-8");
console.log(`✅ VPAT draft written to ${output}`);
