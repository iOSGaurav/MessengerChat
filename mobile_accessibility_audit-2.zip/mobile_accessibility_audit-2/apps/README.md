Place your built apps here for local testing.
- Android: app-debug.apk
- iOS: MyApp.app or MyApp.ipa
