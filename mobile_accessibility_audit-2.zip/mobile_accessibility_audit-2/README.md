# mobile_accessibility_audit

A cross-platform **mobile accessibility audit** toolkit for **Android + iOS** using **Appium** (TalkBack + VoiceOver aware) with:
- Automated checks mapped to **WCAG 2.2** / common mobile a11y heuristics
- Report outputs (JSON + Markdown)
- **AI remediation suggestions** (offline heuristics + optional LLM hook)
- A **VPAT (WCAG) template** you can fill and ship
- One-command runners for Android and iOS

> This repository is designed to be **dropped into an existing mobile project** (native, Flutter, React Native, etc.) and pointed at your built app.

---

## What’s inside

- `tests/android/*.spec.js` – Appium tests & audit pass for Android
- `tests/ios/*.spec.js` – Appium tests & audit pass for iOS
- `src/audit/*` – reusable audit engine (rules, WCAG mapping, report writer)
- `src/remediation/*` – remediation generator (heuristics + optional LLM hook)
- `reports/` – generated output (gitignored)
- `VPAT_WCAG_Template.md` – VPAT-style template
- `docs/` – TalkBack/VoiceOver audit guidance & checklists

---

## Prerequisites

### 1) Install Node.js
Use Node 18+.

### 2) Install Appium + drivers
```bash
npm i
npx appium driver install uiautomator2
npx appium driver install xcuitest
```

### 3) Platform setup
- **Android**: Android Studio + SDK, emulator or device, `adb` available
- **iOS**: macOS + Xcode, Simulator or device, Xcode command line tools

---

## Quick start

### Start Appium server (in a separate terminal)
```bash
npm run appium
```

### Run Android audit
```bash
# Set APK path and main activity/package in env (example below)
export ANDROID_APP=./apps/app-debug.apk
export ANDROID_APP_PACKAGE=com.example.app
export ANDROID_APP_ACTIVITY=.MainActivity

npm run audit:android
```

### Run iOS audit
```bash
export IOS_APP=./apps/MyApp.app  # or .ipa
export IOS_BUNDLE_ID=com.example.app

npm run audit:ios
```

Outputs:
- `reports/<platform>/audit.json`
- `reports/<platform>/audit.md`
- `reports/<platform>/remediation.md`

---

## Environment variables (capabilities)

You can set any of these:

### Android
- `ANDROID_DEVICE_NAME` (default: `Android Emulator`)
- `ANDROID_PLATFORM_VERSION` (optional)
- `ANDROID_APP` (path to .apk) **or** `ANDROID_APP_PACKAGE` + `ANDROID_APP_ACTIVITY`
- `ANDROID_AUTOMATION_NAME` (default: `UiAutomator2`)
- `APPIUM_SERVER` (default: `http://127.0.0.1:4723`)

### iOS
- `IOS_DEVICE_NAME` (default: `iPhone 15`)
- `IOS_PLATFORM_VERSION` (optional)
- `IOS_APP` (path to .app / .ipa) **or** `IOS_BUNDLE_ID`
- `IOS_AUTOMATION_NAME` (default: `XCUITest`)
- `APPIUM_SERVER` (default: `http://127.0.0.1:4723`)

---

## How the audit works

The audit uses Appium to:
1. Launch the app
2. Collect a **snapshot of visible UI elements** (attributes + bounds)
3. Run rule checks (labels, touch target size, duplicate labels, hint/value presence, etc.)
4. Write a report with:
   - Severity
   - Affected elements (selector hints)
   - WCAG mapping
   - Suggested fixes

### TalkBack & VoiceOver
Automation cannot reliably “listen” to screen readers. Instead we:
- Validate the metadata screen readers consume (labels, traits, hints)
- Provide manual verification checklists in `docs/`
- Encourage pairing automated findings with a manual pass (especially focus order, rotor, announcements)

---

## AI remediation

By default the remediation step uses offline heuristics (no network calls).  
You can optionally plug in an LLM by implementing `src/remediation/llmClient.js` (see stub).

Run remediation standalone:
```bash
node scripts/remediate.js --input reports/android/audit.json
```

---

## VPAT

Use `VPAT_WCAG_Template.md` as a starting point for a WCAG/VPAT style deliverable.  
You can also auto-generate a “draft” based on audit findings:
```bash
node scripts/vpat-draft.js --input reports/android/audit.json --output reports/android/VPAT_DRAFT.md
```

---

## Notes / limitations

- These checks are **best-effort heuristics** and will not replace a full accessibility review.
- Contrast checking is not implemented automatically (needs pixel sampling from screenshots and design tokens); see `docs/contrast.md`.
- Focus order and dynamic announcements require manual verification.

---

## License
MIT
