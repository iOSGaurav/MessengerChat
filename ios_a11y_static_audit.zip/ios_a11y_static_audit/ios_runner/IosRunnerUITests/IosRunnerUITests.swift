import XCTest
import Foundation
import CoreGraphics
import UIKit

final class IosRunnerUITests: XCTestCase {

    override func setUp() {
        continueAfterFailure = false
    }

    func testDumpPageTree() throws {
        let targetBundleId = "CodeLiners.SmartTask"
        let outputPath = "/Users/gauravparmar/a11y-audits/run-002/raw/page_tree.json"

        let app = XCUIApplication(bundleIdentifier: targetBundleId)
        app.launch()
        sleep(1)

        let root = app.windows.element(boundBy: 0)
        let dump = serialize(element: root, parentId: nil)

        let url = URL(fileURLWithPath: outputPath)
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)

        let data = try JSONSerialization.data(withJSONObject: dump, options: [.prettyPrinted, .sortedKeys])
        try data.write(to: url, options: [.atomic])
    }

    private func serialize(element: XCUIElement, parentId: String?) -> [String: Any] {
        let id = UUID().uuidString

        let frame = element.frame
        let screenBounds = UIScreen.main.bounds
        let visible = element.exists && frame.intersects(screenBounds)

        let mapped = mapType(element.elementType)

        let node: [String: Any] = [
            "id": id,
            "parent_id": parentId ?? "root",
            "type": mapped.type,
            "role": mapped.role,
            "class": String(describing: element.elementType),
            "label": element.label,
            "value": (element.value as? String) ?? "",
            "identifier": element.identifier,
            "enabled": element.isEnabled,
            "exists": element.exists,
            "hittable": element.isHittable,
            "visible": visible,
            "offscreen": !frame.intersects(screenBounds),
            "accessible": isAccessible(element: element),
            "frame": [
                "x": frame.origin.x,
                "y": frame.origin.y,
                "width": frame.size.width,
                "height": frame.size.height
            ],
            "children": children(of: element, parentId: id)
        ]
        return node
    }

    private func children(of element: XCUIElement, parentId: String) -> [[String: Any]] {
        let query = element.descendants(matching: .any)
        let all = query.allElementsBoundByIndex

        var candidates: [XCUIElement] = []
        for e in all {
            if e == element { continue }
            if e.frame.isEmpty { continue }
            if !element.frame.contains(e.frame) { continue }
            candidates.append(e)
        }

        candidates.sort { area($0.frame) < area($1.frame) }
        var top: [XCUIElement] = []
        for e in candidates {
            var contained = false
            for t in top {
                if t.frame.contains(e.frame) { contained = true; break }
            }
            if !contained { top.append(e) }
        }

        return Array(top.prefix(200)).map { serialize(element: $0, parentId: parentId) }
    }

    private func isAccessible(element: XCUIElement) -> Bool {
        if !element.label.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return true }
        switch element.elementType {
        case .button, .link, .switch, .cell, .tab, .textField, .secureTextField, .slider:
            return true
        default:
            return false
        }
    }

    private func area(_ r: CGRect) -> CGFloat {
        max(0, r.size.width) * max(0, r.size.height)
    }

    private func mapType(_ t: XCUIElement.ElementType) -> (type: String, role: String) {
        switch t {
        case .button: return ("button", "button")
        case .link: return ("link", "link")
        case .staticText: return ("staticText", "text")
        case .textField, .secureTextField: return ("textField", "textbox")
        case .image: return ("image", "image")
        case .switch: return ("switch", "switch")
        case .cell: return ("cell", "listitem")
        case .tab: return ("tab", "tab")
        case .navigationBar: return ("navigationBar", "navigation")
        case .tabBar: return ("tabBar", "tablist")
        default: return ("other", "unknown")
        }
    }
}
