# ios_runner (XCUITest Page Tree extractor)

A minimal Xcode project with a UI test target that:

- Launches the target app using `XCUIApplication(bundleIdentifier: ...)`
- Dumps a machine-readable Page Tree JSON to `PAGE_TREE_OUTPUT`

The MCP server runs it automatically with:

- `TARGET_BUNDLE_ID=<bundle_id>`
- `PAGE_TREE_OUTPUT=<output_dir>/raw/page_tree_*.json`

No private APIs. No Accessibility Inspector automation.
