from __future__ import annotations

import json
import os
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP

from reporting.html_report import build_html_report, build_pdf_from_html, build_fallback_pdf
from rules.engine import run_rules


mcp = FastMCP("ios_a11y_static_audit")


class MCPError(RuntimeError):
    """An error message intended to be returned to Copilot."""


def _run(cmd: List[str], *, cwd: Optional[Path] = None, env: Optional[Dict[str, str]] = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )


def _now_tag() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _sanitize(s: str) -> str:
    return re.sub(r"[^a-zA-Z0-9._-]+", "_", s)


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _booted_sim_udid() -> str:
    proc = _run(["xcrun", "simctl", "list", "devices", "booted", "-j"])
    if proc.returncode != 0:
        raise MCPError(f"Failed to query simulators via simctl.\n{proc.stderr.strip()}")
    data = json.loads(proc.stdout or "{}")
    devices = data.get("devices", {})
    for _runtime, devs in devices.items():
        for d in devs:
            if d.get("state") == "Booted" and d.get("udid"):
                return d["udid"]
    raise MCPError(
        "No booted iOS Simulator detected. Boot a simulator (e.g., from Xcode Devices & Simulators) and rerun."
    )


def _launch_app(udid: str, bundle_id: str) -> None:
    proc = _run(["xcrun", "simctl", "launch", udid, bundle_id])
    if proc.returncode != 0:
        raise MCPError(
            f"Failed to launch app '{bundle_id}' on booted simulator.\n"
            f"simctl stderr:\n{proc.stderr.strip()}\n\n"
            "Remediation:\n- Ensure the app is installed on the booted simulator.\n- Verify bundle_id.\n"
        )


def _capture_screenshot(udid: str, out_png: Path) -> None:
    proc = _run(["xcrun", "simctl", "io", udid, "screenshot", str(out_png)])
    if proc.returncode != 0:
        raise MCPError(f"Failed to capture screenshot via simctl.\n{proc.stderr.strip()}")


def _capture_page_tree_with_xcuitest(udid: str, bundle_id: str, out_json: Path, runner_root: Path) -> None:
    env = os.environ.copy()
    env["TARGET_BUNDLE_ID"] = bundle_id
    env["PAGE_TREE_OUTPUT"] = str(out_json)

    cmd = [
        "xcodebuild",
        "-project", "IosRunner.xcodeproj",
        "-scheme", "IosRunnerUITests",
        "-destination", f"platform=iOS Simulator,id={udid}",
        "test",
        "CODE_SIGNING_ALLOWED=NO",
    ]
    proc = _run(cmd, cwd=runner_root, env=env)
    if proc.returncode != 0:
        raise MCPError(
            "XCUITest runner failed to extract Page Tree.\n\n"
            f"stdout (tail):\n{proc.stdout[-4000:]}\n\n"
            f"stderr (tail):\n{proc.stderr[-4000:]}\n\n"
            "Remediation:\n- Ensure Xcode is installed and initialized (license accepted).\n"
            "- Ensure the app is installed and can launch on the booted simulator.\n"
            "- Ensure bundle_id is correct.\n"
        )
    if not out_json.exists():
        raise MCPError("XCUITest runner completed but did not produce page_tree JSON. Check xcodebuild logs.")


def _file_url(p: Path) -> str:
    return f"file://{p.resolve()}"


@mcp.tool()
def run_ios_static_accessibility_audit(
    bundle_id: str,
    output_dir: str,
    standard: str = "WCAG_2_2_AA",
    include_contrast_check: bool = True,
    include_target_size_check: bool = True,
    report_formats: List[str] = ["html", "pdf", "json"],
    ai_validation: bool = True,
    severity_policy: str = "strict",
) -> Dict[str, Any]:
    """Run a static accessibility audit of the currently visible booted iOS Simulator screen."""

    out_root = Path(output_dir).expanduser()
    raw_dir = out_root / "raw"
    findings_dir = out_root / "findings"
    report_dir = out_root / "report"
    overlays_dir = report_dir / "overlays"
    for d in (raw_dir, findings_dir, report_dir, overlays_dir):
        _ensure_dir(d)

    tag = _now_tag()
    screen_png = raw_dir / f"screenshot_{_sanitize(bundle_id)}_{tag}.png"
    page_json = raw_dir / f"page_tree_{_sanitize(bundle_id)}_{tag}.json"

    udid = _booted_sim_udid()

    _launch_app(udid, bundle_id)
    _capture_screenshot(udid, screen_png)

    runner_root = Path(__file__).resolve().parents[1] / "ios_runner"
    _capture_page_tree_with_xcuitest(udid, bundle_id, page_json, runner_root)

    cfg = {
        "standard": standard,
        "include_contrast_check": include_contrast_check,
        "include_target_size_check": include_target_size_check,
        "ai_validation": ai_validation,
        "severity_policy": severity_policy,
        "bundle_id": bundle_id,
        "simulator_udid": udid,
        "timestamp": tag,
    }

    result = run_rules(page_tree_path=page_json, screenshot_path=screen_png, config=cfg, overlays_dir=overlays_dir)
    findings_path = findings_dir / "findings.json"
    findings_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    html_path = report_dir / "report.html"
    pdf_path = report_dir / "report.pdf"

    if "html" in report_formats or "pdf" in report_formats:
        build_html_report(result=result, screenshot_path=screen_png, overlays_dir=overlays_dir, out_html=html_path)

    if "pdf" in report_formats:
        try:
            build_pdf_from_html(html_path, pdf_path)
        except Exception:
            build_fallback_pdf(result=result, out_pdf=pdf_path, screenshot_path=screen_png)

    score = int(result.get("summary", {}).get("score", 0))
    counts = result.get("summary", {}).get("counts_by_severity", {})
    top5 = result.get("top_issues", [])[:5]

    return {
        "score": score,
        "counts_by_severity": counts,
        "top_5_critical_issues": top5,
        "artifacts": {
            "raw/page_tree.json": _file_url(page_json),
            "raw/screenshot.png": _file_url(screen_png),
            "findings/findings.json": _file_url(findings_path),
            "report/report.html": _file_url(html_path) if html_path.exists() else None,
            "report/report.pdf": _file_url(pdf_path) if pdf_path.exists() else None,
            "report/overlays/": _file_url(overlays_dir),
        },
    }


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
