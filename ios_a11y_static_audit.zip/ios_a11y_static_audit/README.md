# ios_a11y_static_audit

Static iOS accessibility audit for the **currently visible screen** of a **booted iOS Simulator**, triggered from **VS Code Copilot Chat via MCP** (no CLI prompts).

## What this does

When Copilot calls the tool `run_ios_static_accessibility_audit` it will:

1. Detect the currently **booted** iOS Simulator (no selection UI).
2. Launch the target app by `bundle_id` (if not already running).
3. Capture, at the same moment:
   - `raw/screenshot.png` via `xcrun simctl io booted screenshot`
   - `raw/page_tree.json` via a minimal XCUITest UI test runner (`ios_runner/`)
4. Run deterministic rules + optional evidence-fusion “AI validation” (confidence scoring + severity adjustments).
5. Generate artifacts:
   - `findings/findings.json`
   - `report/report.html`
   - `report/report.pdf` (HTML → PDF via WeasyPrint on macOS; fallback PDF summary if WeasyPrint missing)

## Prerequisites (macOS)

- Xcode installed (and command line tools available)
- Python 3.10+
- At least one iOS Simulator **booted** already

> This server does **not** open the Simulator app UI.

## Install

```bash
cd ios_a11y_static_audit
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run with VS Code Copilot MCP

Create `.vscode/mcp.json` in your workspace:

```json
{
  "servers": {
    "ios_a11y_static_audit": {
      "type": "stdio",
      "command": "python3",
      "args": ["-m", "mcp_server"]
    }
  }
}
```

Then call from Copilot Chat with JSON tool arguments, e.g.:

```json
{
  "bundle_id": "com.yourcompany.yourapp",
  "output_dir": "/Users/you/a11y-audits/run-001",
  "standard": "WCAG_2_2_AA",
  "include_contrast_check": true,
  "include_target_size_check": true,
  "report_formats": ["html","pdf","json"],
  "ai_validation": true,
  "severity_policy": "strict"
}
```

## Notes on “AI validation”

- `ai_validation=true` does **not** call a cloud LLM.
- It performs evidence fusion between Page Tree + Screenshot derived signals and assigns a **confidence** score per issue.
- If confidence is low, the engine can **downgrade severity** (never upgrades without strong evidence).

## Output layout

```
output_dir/
  raw/
    screenshot_*.png
    page_tree_*.json
  findings/
    findings.json
  report/
    report.html
    report.pdf
    overlays/
      overlay.png
```

## Troubleshooting

### No booted iOS simulator
Boot any simulator from Xcode (Window → Devices and Simulators) or `simctl` (outside this tool), then rerun.

### Xcodebuild / UI test runner failures
- Ensure the app is installed on the booted simulator (or provide correct bundle id)
- Ensure Xcode license accepted:
  ```bash
  sudo xcodebuild -license accept
  ```

### PDF generation
WeasyPrint may require cairo/pango. If WeasyPrint fails, the tool still produces HTML and a fallback PDF summary.
