Place sample output artifacts here.
