from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from PIL import Image, ImageDraw


def draw_overlays(base_image_path: Path, issues: List[Dict[str, Any]], out_path: Path) -> None:
    img = Image.open(base_image_path).convert("RGBA")
    draw = ImageDraw.Draw(img)

    for it in issues:
        node = it.get("node") or {}
        fr = node.get("frame")
        if not fr:
            continue
        x1 = int(fr["x"])
        y1 = int(fr["y"])
        x2 = int(fr["x"] + fr["width"])
        y2 = int(fr["y"] + fr["height"])
        draw.rectangle([x1, y1, x2, y2], outline="red", width=3)
        draw.text((x1 + 4, y1 + 4), it.get("id", ""), fill="red")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path)
