from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

from jinja2 import Environment, FileSystemLoader, select_autoescape


def build_html_report(result: Dict[str, Any], screenshot_path: Path, overlays_dir: Path, out_html: Path) -> None:
    env = Environment(
        loader=FileSystemLoader(str(Path(__file__).parent / "templates")),
        autoescape=select_autoescape(["html", "xml"]),
    )
    tpl = env.get_template("report.html.j2")

    overlay_path = overlays_dir / "overlay.png"
    out_html.parent.mkdir(parents=True, exist_ok=True)

    html = tpl.render(
        meta=result.get("meta", {}),
        summary=result.get("summary", {}),
        issues=result.get("issues", []),
        top_issues=result.get("top_issues", []),
        screenshot=str(screenshot_path),
        overlay=str(overlay_path) if overlay_path.exists() else None,
    )
    out_html.write_text(html, encoding="utf-8")


def build_pdf_from_html(html_path: Path, out_pdf: Path) -> None:
    from weasyprint import HTML  # type: ignore
    out_pdf.parent.mkdir(parents=True, exist_ok=True)
    HTML(filename=str(html_path)).write_pdf(str(out_pdf))


def build_fallback_pdf(result: Dict[str, Any], out_pdf: Path, screenshot_path: Path) -> None:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import inch
    from reportlab.pdfgen import canvas

    out_pdf.parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(out_pdf), pagesize=letter)
    width, height = letter

    y = height - 0.75 * inch
    c.setFont("Helvetica-Bold", 16)
    c.drawString(0.75 * inch, y, "iOS Static Accessibility Audit (Fallback PDF)")
    y -= 0.4 * inch

    c.setFont("Helvetica", 11)
    meta = result.get("meta", {})
    summ = result.get("summary", {})
    c.drawString(0.75 * inch, y, f"Bundle ID: {meta.get('bundle_id')}")
    y -= 0.22 * inch
    c.drawString(0.75 * inch, y, f"Simulator UDID: {meta.get('simulator_udid')}")
    y -= 0.22 * inch
    c.drawString(0.75 * inch, y, f"Timestamp: {meta.get('timestamp')}")
    y -= 0.3 * inch
    c.drawString(0.75 * inch, y, f"Score: {summ.get('score')} / 100")
    y -= 0.3 * inch
    c.drawString(0.75 * inch, y, f"Counts: {summ.get('counts_by_severity', {})}")
    y -= 0.35 * inch

    c.setFont("Helvetica-Bold", 12)
    c.drawString(0.75 * inch, y, "Top Issues")
    y -= 0.25 * inch

    c.setFont("Helvetica", 10)
    for it in (result.get("top_issues") or [])[:10]:
        line = f"{it.get('severity','').upper()} {it.get('id')}: {it.get('title')}"
        c.drawString(0.85 * inch, y, line[:120])
        y -= 0.18 * inch
        if y < 1.0 * inch:
            c.showPage()
            y = height - 0.75 * inch
            c.setFont("Helvetica", 10)

    c.showPage()
    c.save()
