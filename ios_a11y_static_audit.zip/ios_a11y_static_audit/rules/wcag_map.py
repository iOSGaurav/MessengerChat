WCAG = {
  "missing_label": ["WCAG 4.1.2", "WCAG 1.1.1"],
  "generic_label": ["WCAG 4.1.2"],
  "duplicate_label": ["WCAG 3.3.2", "WCAG 2.4.6"],
  "small_target": ["WCAG 2.5.5"],
  "overlapping_targets": ["WCAG 2.5.5"],
  "contrast_text": ["WCAG 1.4.3"],
  "contrast_nontext": ["WCAG 1.4.11"],
  "hidden_exposed": ["WCAG 4.1.2"],
  "name_role_value": ["WCAG 4.1.2"],
  "grouping": ["WCAG 1.3.1"],
  "heading_hierarchy": ["WCAG 1.3.1", "WCAG 2.4.6"],
  "focus_order": ["WCAG 2.4.3"],
}
