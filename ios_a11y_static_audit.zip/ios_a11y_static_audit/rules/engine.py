from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image

from rules.wcag_map import WCAG
from reporting.overlay import draw_overlays


SEVERITY_ORDER = ["critical", "high", "medium", "low", "info"]


def _severity_rank(s: str) -> int:
    try:
        return SEVERITY_ORDER.index(s)
    except ValueError:
        return len(SEVERITY_ORDER)


def _rect_intersection(a: Dict[str, float], b: Dict[str, float]) -> float:
    ax1, ay1 = a["x"], a["y"]
    ax2, ay2 = a["x"] + a["width"], a["y"] + a["height"]
    bx1, by1 = b["x"], b["y"]
    bx2, by2 = b["x"] + b["width"], b["y"] + b["height"]
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0
    return (ix2 - ix1) * (iy2 - iy1)


def _center(a: Dict[str, float]) -> Tuple[float, float]:
    return (a["x"] + a["width"] / 2.0, a["y"] + a["height"] / 2.0)


def _dist(a: Dict[str, float], b: Dict[str, float]) -> float:
    (cx1, cy1), (cx2, cy2) = _center(a), _center(b)
    return math.hypot(cx1 - cx2, cy1 - cy2)


def _luminance(rgb: Tuple[int, int, int]) -> float:
    def chan(c: float) -> float:
        c = c / 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = rgb
    return 0.2126 * chan(r) + 0.7152 * chan(g) + 0.0722 * chan(b)


def _contrast_ratio(fg: Tuple[int, int, int], bg: Tuple[int, int, int]) -> float:
    L1 = _luminance(fg)
    L2 = _luminance(bg)
    lighter, darker = (L1, L2) if L1 >= L2 else (L2, L1)
    return (lighter + 0.05) / (darker + 0.05)


def _sample_box(img: Image.Image, box: Tuple[int, int, int, int]) -> List[Tuple[int, int, int]]:
    x1, y1, x2, y2 = box
    x1 = max(0, min(img.width - 1, x1))
    y1 = max(0, min(img.height - 1, y1))
    x2 = max(0, min(img.width, x2))
    y2 = max(0, min(img.height, y2))
    if x2 <= x1 or y2 <= y1:
        return []
    step_x = max(1, (x2 - x1) // 20)
    step_y = max(1, (y2 - y1) // 20)
    px = img.load()
    out: List[Tuple[int, int, int]] = []
    for y in range(y1, y2, step_y):
        for x in range(x1, x2, step_x):
            r, g, b = px[x, y][:3]
            out.append((r, g, b))
    return out


def _median_rgb(pixels: List[Tuple[int, int, int]]) -> Tuple[int, int, int]:
    if not pixels:
        return (0, 0, 0)
    rs = sorted(p[0] for p in pixels)
    gs = sorted(p[1] for p in pixels)
    bs = sorted(p[2] for p in pixels)
    mid = len(pixels) // 2
    return (rs[mid], gs[mid], bs[mid])


def _flatten(node: Dict[str, Any], out: List[Dict[str, Any]]) -> None:
    out.append(node)
    for c in node.get("children", []) or []:
        _flatten(c, out)


def _is_tappable(n: Dict[str, Any]) -> bool:
    t = (n.get("type") or "").lower()
    return t in ("button", "link", "cell", "switch", "tab", "segmentedcontrol") or (t == "other" and n.get("role") in ("button", "link"))


def _normalize_label(s: str) -> str:
    return " ".join((s or "").strip().lower().split())


def run_rules(page_tree_path: Path, screenshot_path: Path, config: Dict[str, Any], overlays_dir: Path) -> Dict[str, Any]:
    tree = json.loads(page_tree_path.read_text(encoding="utf-8"))
    nodes: List[Dict[str, Any]] = []
    _flatten(tree, nodes)

    issues: List[Dict[str, Any]] = []
    idx = 0

    def add_issue(code: str, severity: str, title: str, node: Optional[Dict[str, Any]], details: Dict[str, Any], evidence: Dict[str, Any], confidence: float) -> None:
        nonlocal idx
        idx += 1
        issues.append({
            "id": f"ISSUE-{idx:04d}",
            "code": code,
            "severity": severity,
            "title": title,
            "wcag": WCAG.get(code, []),
            "confidence": round(float(confidence), 3),
            "node": node,
            "details": details,
            "evidence": evidence,
        })

    ai = bool(config.get("ai_validation", True))

    # Page-tree rules
    for n in nodes:
        if not n.get("visible", True):
            continue
        label = n.get("label") or ""
        ident = n.get("identifier") or ""
        role = n.get("role") or ""
        typ = (n.get("type") or "").lower()

        if _is_tappable(n):
            if _normalize_label(label) == "" and _normalize_label(ident) == "":
                add_issue(
                    "missing_label", "critical",
                    "Interactive element missing accessible name",
                    n,
                    {"why": "Interactive controls need an accessible name so VoiceOver can announce them."},
                    {"label": label, "identifier": ident},
                    0.95 if ai else 1.0,
                )
            if _normalize_label(label) in ("button", "image", "icon", "item"):
                add_issue(
                    "generic_label", "high",
                    "Generic accessible name (not descriptive)",
                    n,
                    {"why": "Labels like 'button' do not convey purpose."},
                    {"label": label},
                    0.85 if ai else 1.0,
                )
            if typ == "other" and role in ("", "unknown"):
                add_issue(
                    "name_role_value", "high",
                    "Custom control may be missing role/traits",
                    n,
                    {"why": "Custom controls should expose role/state/value to assistive tech."},
                    {"type": typ, "role": role},
                    0.6 if ai else 1.0,
                )

        if n.get("exists", True) and not n.get("hittable", True) and n.get("accessible", False) and n.get("offscreen", False):
            add_issue(
                "hidden_exposed", "medium",
                "Offscreen/hidden element exposed to accessibility",
                n,
                {"why": "Elements not visible should typically be hidden from accessibility."},
                {"offscreen": True},
                0.75 if ai else 1.0,
            )

    # Duplicate labels per parent
    by_parent: Dict[str, List[Dict[str, Any]]] = {}
    for n in nodes:
        if not n.get("visible", True) or not _is_tappable(n):
            continue
        pid = n.get("parent_id", "root")
        by_parent.setdefault(pid, []).append(n)

    for pid, arr in by_parent.items():
        buckets: Dict[str, List[Dict[str, Any]]] = {}
        for n in arr:
            key = _normalize_label(n.get("label", "")) or _normalize_label(n.get("identifier", ""))
            if not key:
                continue
            buckets.setdefault(key, []).append(n)
        for key, lst in buckets.items():
            if len(lst) >= 2:
                for n in lst[:3]:
                    add_issue(
                        "duplicate_label", "medium",
                        "Duplicate accessible names in the same context",
                        n,
                        {"why": "Duplicate labels make controls hard to distinguish in VoiceOver."},
                        {"dup_key": key, "count": len(lst)},
                        0.7 if ai else 1.0,
                    )

    img = Image.open(screenshot_path).convert("RGBA")
    tappables = [n for n in nodes if n.get("visible", True) and _is_tappable(n) and n.get("frame")]

    # Target size
    if config.get("include_target_size_check", True):
        for n in tappables:
            fr = n["frame"]
            if fr["width"] < 44 or fr["height"] < 44:
                conf = 0.9
                sev = "high"
                if ai and fr["width"] >= 40 and fr["height"] >= 40:
                    sev = "medium"
                    conf = 0.6
                add_issue(
                    "small_target", sev,
                    "Touch target smaller than 44×44 pt",
                    n,
                    {"recommended_min": [44, 44], "actual": [fr["width"], fr["height"]]},
                    {"frame": fr},
                    conf if ai else 1.0,
                )

    # Overlap/crowding
    for i in range(len(tappables)):
        for j in range(i + 1, len(tappables)):
            a, b = tappables[i], tappables[j]
            ia = _rect_intersection(a["frame"], b["frame"])
            if ia > 0:
                add_issue(
                    "overlapping_targets", "high",
                    "Overlapping touch targets",
                    a,
                    {"other_element_id": b.get("id"), "intersection_area": ia},
                    {"frame_a": a["frame"], "frame_b": b["frame"]},
                    0.85 if ai else 1.0,
                )
            else:
                if _dist(a["frame"], b["frame"]) < 44:
                    add_issue(
                        "overlapping_targets", "medium",
                        "Crowded touch targets (too close together)",
                        a,
                        {"other_element_id": b.get("id"), "center_distance": round(_dist(a["frame"], b["frame"]), 2)},
                        {"frame_a": a["frame"], "frame_b": b["frame"]},
                        0.55 if ai else 1.0,
                    )

    # Contrast heuristics
    if config.get("include_contrast_check", True):
        for n in nodes:
            if not n.get("visible", True):
                continue
            fr = n.get("frame")
            if not fr:
                continue
            x1, y1 = int(fr["x"]), int(fr["y"])
            x2, y2 = int(fr["x"] + fr["width"]), int(fr["y"] + fr["height"])
            if x2 <= x1 + 4 or y2 <= y1 + 4:
                continue

            border = _sample_box(img, (x1, y1, x2, min(y1 + 6, y2)))
            border += _sample_box(img, (x1, max(y2 - 6, y1), x2, y2))
            border += _sample_box(img, (x1, y1, min(x1 + 6, x2), y2))
            border += _sample_box(img, (max(x2 - 6, x1), y1, x2, y2))

            center = _sample_box(img, (x1 + (x2 - x1)//4, y1 + (y2 - y1)//4, x1 + 3*(x2 - x1)//4, y1 + 3*(y2 - y1)//4))

            bg = _median_rgb(border)
            fg = _median_rgb(center)
            ratio = _contrast_ratio(fg, bg)

            typ = (n.get("type") or "").lower()
            if typ == "statictext" and ratio < 4.5:
                sev = "high" if ratio < 3.0 else "medium"
                conf = 0.55 if ai else 1.0
                if ai and conf < 0.6 and sev == "high":
                    sev = "medium"
                add_issue(
                    "contrast_text", sev,
                    "Possible text contrast failure (heuristic)",
                    n,
                    {"measured_ratio": round(ratio, 2), "threshold": 4.5},
                    {"fg": fg, "bg": bg, "frame": fr},
                    conf if ai else 1.0,
                )
            elif _is_tappable(n) and ratio < 3.0:
                add_issue(
                    "contrast_nontext", "medium",
                    "Possible non-text contrast failure (heuristic)",
                    n,
                    {"measured_ratio": round(ratio, 2), "threshold": 3.0},
                    {"fg": fg, "bg": bg, "frame": fr},
                    0.45 if ai else 1.0,
                )

    # Focus order anomaly
    spatial = []
    tree_order = []
    for i, n in enumerate(tappables):
        fr = n["frame"]
        spatial.append((fr["y"], fr["x"], i))
        tree_order.append(i)
    spatial_sorted = sorted(spatial, key=lambda t: (t[0], t[1]))
    inversions = 0
    if spatial_sorted:
        pos = {i: rank for rank, (_y, _x, i) in enumerate(spatial_sorted)}
        ranks = [pos[i] for i in tree_order]
        for i in range(len(ranks)):
            for j in range(i + 1, len(ranks)):
                if ranks[i] > ranks[j]:
                    inversions += 1
        max_inv = len(ranks) * (len(ranks) - 1) // 2
        if max_inv > 0:
            inv_ratio = inversions / max_inv
            if inv_ratio > 0.35 and len(ranks) >= 6:
                add_issue(
                    "focus_order", "medium",
                    "Potential focus order anomaly (tree vs spatial order)",
                    tappables[0] if tappables else None,
                    {"inversion_ratio": round(inv_ratio, 2)},
                    {"inversions": inversions, "elements": len(ranks)},
                    0.5 if ai else 1.0,
                )

    # AI downgrade by low confidence
    if ai:
        for it in issues:
            c = float(it.get("confidence", 1.0))
            if c < 0.5:
                sev = it["severity"]
                if sev == "critical":
                    it["severity"] = "high"
                elif sev == "high":
                    it["severity"] = "medium"
                elif sev == "medium":
                    it["severity"] = "low"

    # Score
    counts = {s: 0 for s in SEVERITY_ORDER}
    for it in issues:
        counts[it["severity"]] = counts.get(it["severity"], 0) + 1

    policy = (config.get("severity_policy") or "strict").lower()
    penalty = 0.0
    for it in issues:
        sev = it["severity"]
        conf = float(it.get("confidence", 1.0))
        weight = {"critical": 8, "high": 4, "medium": 2, "low": 1, "info": 0.2} if policy == "strict" else {"critical": 6, "high": 3, "medium": 1.5, "low": 0.7, "info": 0.2}
        penalty += weight.get(sev, 1) * max(0.25, conf)
    score = max(0, int(round(100 - penalty)))

    issues_sorted = sorted(issues, key=lambda x: (_severity_rank(x["severity"]), -float(x.get("confidence", 0.0))))

    overlay_path = overlays_dir / "overlay.png"
    draw_overlays(base_image_path=screenshot_path, issues=issues_sorted, out_path=overlay_path)

    for it in issues_sorted:
        it["recommendation"] = _recommendation(it)

    return {
        "meta": {
            "standard": config.get("standard"),
            "bundle_id": config.get("bundle_id"),
            "simulator_udid": config.get("simulator_udid"),
            "timestamp": config.get("timestamp"),
        },
        "summary": {
            "score": score,
            "counts_by_severity": counts,
            "issue_count": len(issues_sorted),
        },
        "top_issues": [it for it in issues_sorted if it["severity"] in ("critical", "high")][:10],
        "issues": issues_sorted,
        "artifacts": {"overlay_png": str(overlay_path)},
    }


def _recommendation(issue: Dict[str, Any]) -> Dict[str, str]:
    code = issue.get("code")
    rec = {"swiftui": "", "uikit": ""}

    if code in ("missing_label", "generic_label"):
        rec["swiftui"] = (
            "```swift\n"
            "Button(action: { /* ... */ }) {\n"
            "  Image(systemName: \"trash\")\n"
            "}\n"
            ".accessibilityLabel(\"Delete item\")\n"
            ".accessibilityHint(\"Removes this item from the list\")\n"
            "```"
        )
        rec["uikit"] = (
            "```swift\n"
            "deleteButton.accessibilityLabel = \"Delete item\"\n"
            "deleteButton.accessibilityHint = \"Removes this item from the list\"\n"
            "```"
        )
    elif code == "small_target":
        rec["swiftui"] = (
            "```swift\n"
            "Button(\"…\") { /* ... */ }\n"
            "  .frame(minWidth: 44, minHeight: 44)\n"
            "  .contentShape(Rectangle())\n"
            "```"
        )
        rec["uikit"] = "Increase hit area (e.g., container view, or override point(inside:with:) in a custom control)."
    elif code in ("contrast_text", "contrast_nontext"):
        rec["swiftui"] = (
            "```swift\n"
            "Text(\"Title\")\n"
            "  .foregroundStyle(.primary)\n"
            "  .background(.background)\n"
            "```"
        )
        rec["uikit"] = "Use dynamic system colors (label/systemBackground) and verify contrast in light/dark."
    elif code == "overlapping_targets":
        rec["swiftui"] = "Add spacing/padding to separate tap targets; avoid overlapping frames."
        rec["uikit"] = "Adjust constraints to prevent overlapping hit areas (StackView/spacing)."
    elif code == "focus_order":
        rec["swiftui"] = "Use accessibilitySortPriority to stabilize order when necessary."
        rec["uikit"] = "Set accessibilityElements order on container views."
    else:
        rec["swiftui"] = "Review the element’s accessibility properties and align with iOS best practices."
        rec["uikit"] = "Review the element’s accessibility properties and align with iOS best practices."
    return rec
