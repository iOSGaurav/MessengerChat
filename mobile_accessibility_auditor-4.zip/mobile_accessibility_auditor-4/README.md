# mobile_accessibility_auditor

Standalone, CI-friendly mobile accessibility auditing tool for **iOS + Android** using **real Appium sessions** and a **deterministic WCAG 2.2 (A + AA) rule engine** with an **optional AI-assist layer** (OFF by default).

> **Important**: This tool performs automated UI traversal and may click/tap elements. Always run against test/staging builds and accounts.

---

## Features

- ✅ Real Appium sessions (XCUITest/WDA for iOS, UiAutomator2 for Android)
- ✅ Automatic screen exploration (graph-based traversal with loop detection)
- ✅ Deterministic WCAG 2.2 rule engine (A + AA)
- ✅ Evidence capture per screen (screenshot + UI hierarchy + metadata)
- ✅ Reports: JSON + HTML + optional PDF
- ✅ Optional AI-assisted suggestions (never used for pass/fail)
- ✅ Interactive CLI flow + non-interactive CI mode
- ✅ MCP-style server entrypoint: `python -m mobile_accessibility_auditor.mcp_server`

---

## Quick start

### 1) Install prerequisites

See:
- `docs/01_getting_started.md`
- `docs/06_troubleshooting.md`

### 2) Install the tool

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
```

### 3) Start Appium

```bash
appium --address 127.0.0.1 --port 4723
```

### 4) Run CLI (interactive)

```bash
python -m mobile_accessibility_auditor.cli
```

### 5) Run CLI (CI / non-interactive)

```bash
python -m mobile_accessibility_auditor.cli --config examples/config.android.yaml --ci
```

### 6) Run as MCP server (stdio JSON-RPC)

```bash
python -m mobile_accessibility_auditor.mcp_server
```

Send JSON lines to stdin:
```json
{"id":"1","method":"validate_environment","params":{}}
{"id":"2","method":"list_targets","params":{}}
{"id":"3","method":"run_audit","params":{"config_path":"examples/config.android.yaml"}}
```

---

## Docs

- `docs/01_getting_started.md`
- `docs/02_configuration.md`
- `docs/03_exploration_engine.md`
- `docs/04_wcag_mapping.md`
- `docs/05_reports.md`
- `docs/06_troubleshooting.md`
- `docs/07_ai_mode.md`

---

## License

MIT (see `LICENSE`).


## Additional Docs
- `docs/08_voiceover_suite.md`
