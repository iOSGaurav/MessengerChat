from __future__ import annotations
import json
import time
from typing import Any, Dict

BY_MAP = {
    "accessibility_id": "accessibility id",
    "id": "id",
    "xpath": "xpath",
    "android_uiautomator": "-android uiautomator",
    "ios_predicate": "-ios predicate string",
    "class": "class name",
}

def run_seed_steps(driver, path: str) -> None:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    steps = data.get("steps", [])
    for i, step in enumerate(steps, start=1):
        action = step.get("action")
        by = BY_MAP.get(step.get("by"), step.get("by"))
        value = step.get("value")
        if not action or not by or not value:
            raise ValueError(f"Invalid seed step #{i}: {step}")
        if action == "tap":
            el = driver.find_element(by, value)
            el.click()
        elif action == "type":
            text = step.get("text", "")
            el = driver.find_element(by, value)
            try:
                el.clear()
            except Exception:
                pass
            el.send_keys(text)
        elif action == "wait":
            seconds = float(step.get("seconds", 1.0))
            time.sleep(seconds)
        else:
            raise ValueError(f"Unsupported seed step action: {action}")
        time.sleep(float(step.get("post_delay_seconds", 0.3)))
