from __future__ import annotations
import os
import time
from typing import Any, Dict, Optional, List
from appium import webdriver
from appium.options.ios import XCUITestOptions
from .base import PlatformDriver, DriverSession
from ..utils.subprocesses import run_cmd
from ..utils.logging import get_logger

log = get_logger(__name__)

def _simctl_list_devices() -> Dict[str, Any]:
    rc, out, err = run_cmd(["xcrun", "simctl", "list", "devices", "--json"], timeout=30)
    if rc != 0:
        return {"error": err.strip()}
    import json
    return json.loads(out)

def _xctrace_list_devices() -> List[Dict[str, str]]:
    # Lists sims + physical devices that Xcode sees
    rc, out, err = run_cmd(["xcrun", "xctrace", "list", "devices"], timeout=30)
    if rc != 0:
        return []
    devices: List[Dict[str, str]] = []
    for line in out.splitlines():
        line = line.strip()
        if not line or line.startswith("=="):
            continue
        # Typical: "iPhone 15 (17.2) (UUID)"
        # or: "Gaurav’s iPhone (17.1.1) (00008030-...)"
        if "(" in line and ")" in line:
            devices.append({"raw": line})
    return devices

class IOSDriver(PlatformDriver):
    platform = "ios"

    def __init__(self, appium_server_url: str, udid: Optional[str], device_name: Optional[str], app: Dict[str, Any], capabilities: Optional[Dict[str, Any]] = None):
        self.server = appium_server_url
        self.udid = udid
        self.device_name = device_name
        self.app = app
        self.capabilities = capabilities or {}

    def list_targets(self) -> Dict[str, Any]:
        sims = _simctl_list_devices()
        xctrace = _xctrace_list_devices()
        return {"ios": {"simctl": sims, "xctrace_devices": xctrace}}

    def get_device_metadata(self) -> Dict[str, Any]:
        meta: Dict[str, Any] = {}
        if self.udid:
            meta["udid"] = self.udid
        if self.device_name:
            meta["device_name"] = self.device_name
        return meta

    def create_session(self) -> DriverSession:
        opts = XCUITestOptions()
        always = dict(self.capabilities)
        always.setdefault("platformName", "iOS")
        always.setdefault("appium:automationName", "XCUITest")
        if self.udid:
            always.setdefault("appium:udid", self.udid)
        if self.device_name:
            always.setdefault("appium:deviceName", self.device_name)
        always.setdefault("appium:newCommandTimeout", 300)

        method = (self.app.get("method") or "").lower()
        if method == "bundleid" and self.app.get("bundleId"):
            always.setdefault("appium:bundleId", self.app.get("bundleId"))
        elif method == "app" and self.app.get("appPath"):
            always.setdefault("appium:app", os.path.abspath(self.app["appPath"]))
        elif method == "ipa" and self.app.get("ipaPath"):
            always.setdefault("appium:app", os.path.abspath(self.app["ipaPath"]))
        else:
            pass

        # Sensible defaults for stability
        always.setdefault("appium:waitForQuiescence", False)
        always.setdefault("appium:shouldUseSingletonTestManager", True)

        opts.load_capabilities(always)
        log.info("Creating iOS Appium session: %s", self.server)
        driver = webdriver.Remote(command_executor=self.server, options=opts)
        driver.implicitly_wait(2.0)
        return driver

    def supports_deeplink(self) -> bool:
        return True

    def open_deeplink(self, session: DriverSession, url: str) -> None:
        # iOS mobile: deepLink generally supported by Appium XCUITest
        session.execute_script("mobile: deepLink", {"url": url, "bundleId": self.app.get("bundleId")})

    def perform_back(self, session: DriverSession) -> None:
        # Prefer visible nav bar back button; fallback to edge swipe.
        try:
            # common back labels
            candidates = session.find_elements("accessibility id", "Back")
            if candidates:
                candidates[0].click()
                return
        except Exception:
            pass
        # Edge swipe gesture (left-to-right)
        try:
            session.execute_script("mobile: swipe", {"direction": "right"})
            return
        except Exception:
            pass
        try:
            session.execute_script("mobile: swipeGesture", {"direction": "right", "percent": 0.7})
        except Exception:
            # last resort
            try:
                session.back()
            except Exception:
                pass

    def perform_swipe(self, session: DriverSession, direction: str) -> None:
        direction = direction.lower()
        try:
            session.execute_script("mobile: swipeGesture", {"direction": direction, "percent": 0.7})
        except Exception:
            try:
                session.execute_script("mobile: swipe", {"direction": direction})
            except Exception as e:
                log.warning("Swipe failed: %s", e)
