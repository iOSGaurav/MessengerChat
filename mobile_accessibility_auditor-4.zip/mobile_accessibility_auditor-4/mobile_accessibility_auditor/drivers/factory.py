from __future__ import annotations
from typing import Any, Dict, Optional
from ..config import RootConfig
from .android import AndroidDriver
from .ios import IOSDriver

def build_driver(cfg: RootConfig):
    caps = cfg.capabilities.alwaysMatch if cfg.capabilities else None
    if cfg.platform == "android":
        return AndroidDriver(
            appium_server_url=cfg.appium_server_url,
            device_udid=cfg.targets.android.device_udid,
            app=cfg.app.model_dump(),
            capabilities=caps,
        )
    else:
        return IOSDriver(
            appium_server_url=cfg.appium_server_url,
            udid=cfg.targets.ios.udid,
            device_name=cfg.targets.ios.device_name,
            app=cfg.app.model_dump(),
            capabilities=caps,
        )
