from __future__ import annotations
import os
import time
from typing import Any, Dict, Optional, Tuple, List
from appium import webdriver
from appium.options.android import UiAutomator2Options
from .base import PlatformDriver, DriverSession
from ..utils.subprocesses import run_cmd
from ..utils.logging import get_logger

log = get_logger(__name__)

def _parse_adb_devices(output: str) -> List[Dict[str, str]]:
    devices: List[Dict[str, str]] = []
    lines = [l.strip() for l in output.splitlines() if l.strip()]
    for l in lines:
        if l.startswith("List of devices"):
            continue
        parts = l.split()
        if len(parts) >= 2:
            udid, state = parts[0], parts[1]
            if udid == "offline":
                continue
            devices.append({"udid": udid, "state": state, "raw": l})
    return devices

class AndroidDriver(PlatformDriver):
    platform = "android"

    def __init__(self, appium_server_url: str, device_udid: Optional[str], app: Dict[str, Any], capabilities: Optional[Dict[str, Any]] = None):
        self.server = appium_server_url
        self.device_udid = device_udid
        self.app = app
        self.capabilities = capabilities or {}

    def list_targets(self) -> Dict[str, Any]:
        rc, out, err = run_cmd(["adb", "devices", "-l"], timeout=20)
        if rc != 0:
            return {"android": {"error": err.strip(), "devices": []}}
        devices = _parse_adb_devices(out)
        return {"android": {"devices": devices}}

    def get_device_metadata(self) -> Dict[str, Any]:
        meta: Dict[str, Any] = {}
        if not self.device_udid:
            return meta
        for prop in ["ro.build.version.release", "ro.product.model", "ro.product.manufacturer"]:
            rc, out, _ = run_cmd(["adb", "-s", self.device_udid, "shell", "getprop", prop], timeout=10)
            if rc == 0:
                meta[prop] = out.strip()
        return meta

    def create_session(self) -> DriverSession:
        opts = UiAutomator2Options()
        # Merge capabilities (W3C)
        always = dict(self.capabilities)  # already flattened
        # Provide defaults
        always.setdefault("platformName", "Android")
        always.setdefault("appium:automationName", "UiAutomator2")
        if self.device_udid:
            always.setdefault("appium:udid", self.device_udid)
            always.setdefault("appium:deviceName", self.device_udid)
        always.setdefault("appium:newCommandTimeout", 300)
        always.setdefault("appium:autoGrantPermissions", True)
        always.setdefault("appium:disableWindowAnimation", True)

        method = (self.app.get("method") or "").lower()
        if method == "apk" and self.app.get("apkPath"):
            always.setdefault("appium:app", os.path.abspath(self.app["apkPath"]))
        elif method == "package_activity":
            always.setdefault("appium:appPackage", self.app.get("appPackage"))
            always.setdefault("appium:appActivity", self.app.get("appActivity"))
        else:
            # If user provides raw capabilities, they control app launch.
            pass

        opts.load_capabilities(always)
        log.info("Creating Android Appium session: %s", self.server)
        driver = webdriver.Remote(command_executor=self.server, options=opts)
        driver.implicitly_wait(2.0)
        return driver

    def supports_deeplink(self) -> bool:
        return True

    def open_deeplink(self, session: DriverSession, url: str) -> None:
        # Appium mobile:deepLink is supported on Android
        try:
            session.execute_script("mobile: deepLink", {"url": url, "package": self.app.get("appPackage")})
        except Exception:
            # Fallback: adb intent
            if not self.device_udid:
                raise
            run_cmd(["adb", "-s", self.device_udid, "shell", "am", "start", "-W", "-a", "android.intent.action.VIEW", "-d", url], timeout=20)

    def perform_back(self, session: DriverSession) -> None:
        try:
            session.back()
            return
        except Exception:
            pass
        if self.device_udid:
            run_cmd(["adb", "-s", self.device_udid, "shell", "input", "keyevent", "4"], timeout=10)

    def perform_swipe(self, session: DriverSession, direction: str) -> None:
        # W3C actions via Appium "mobile: swipeGesture" preferred
        direction = direction.lower()
        args = {"direction": direction, "percent": 0.7}
        try:
            session.execute_script("mobile: swipeGesture", args)
        except Exception:
            # fallback: touchAction-style swipe via W3C pointer is complex; try scrollGesture
            try:
                session.execute_script("mobile: scrollGesture", {"direction": direction, "percent": 0.7})
            except Exception as e:
                log.warning("Swipe failed: %s", e)
