from __future__ import annotations
import time
from dataclasses import dataclass

@dataclass
class Budget:
    start_monotonic: float
    time_budget_seconds: float

    @classmethod
    def from_minutes(cls, minutes: float) -> "Budget":
        return cls(start_monotonic=time.monotonic(), time_budget_seconds=minutes * 60.0)

    def remaining(self) -> float:
        elapsed = time.monotonic() - self.start_monotonic
        return max(0.0, self.time_budget_seconds - elapsed)

    def expired(self) -> bool:
        return self.remaining() <= 0.0
