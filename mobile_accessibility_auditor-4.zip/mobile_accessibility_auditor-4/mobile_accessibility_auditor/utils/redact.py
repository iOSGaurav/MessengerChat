from __future__ import annotations
import re
from typing import Iterable

SENSITIVE_PATTERNS = [
    (re.compile(r"\b\d{12,19}\b"), "[REDACTED_NUMBER]"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "[REDACTED_SSN]"),
    (re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE), "[REDACTED_EMAIL]"),
    (re.compile(r"\b\+?\d[\d\s-]{8,}\b"), "[REDACTED_PHONE]"),
]

DEFAULT_SAFE_KEYS = {"text", "label", "name", "value", "content-desc", "contentDescription", "hint"}

def redact_text(s: str) -> str:
    out = s
    for pat, rep in SENSITIVE_PATTERNS:
        out = pat.sub(rep, out)
    return out

def redact_any_strings_in_obj(obj):
    if isinstance(obj, str):
        return redact_text(obj)
    if isinstance(obj, list):
        return [redact_any_strings_in_obj(x) for x in obj]
    if isinstance(obj, dict):
        return {k: redact_any_strings_in_obj(v) for k, v in obj.items()}
    return obj
