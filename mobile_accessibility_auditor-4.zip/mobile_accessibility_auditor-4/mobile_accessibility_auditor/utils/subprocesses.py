from __future__ import annotations
import subprocess
from typing import List, Tuple, Optional

def run_cmd(cmd: List[str], timeout: int = 30) -> Tuple[int, str, str]:
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout, p.stderr

def cmd_exists(cmd: str) -> bool:
    try:
        subprocess.run([cmd, "--version"], capture_output=True, text=True, timeout=10)
        return True
    except Exception:
        return False
