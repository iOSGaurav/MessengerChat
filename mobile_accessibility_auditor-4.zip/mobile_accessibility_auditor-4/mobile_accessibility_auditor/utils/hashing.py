from __future__ import annotations
import hashlib

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()

def stable_hash_parts(parts: list[str]) -> str:
    joined = "\n".join(parts)
    return sha256_text(joined)[:16]
