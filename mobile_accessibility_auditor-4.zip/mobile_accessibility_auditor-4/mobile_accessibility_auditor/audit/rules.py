from __future__ import annotations
import os
from typing import Any, Dict, List, Tuple
from .models import Finding
from ..explorer.models import ScreenCapture, ElementInfo
from ..utils.logging import get_logger

log = get_logger(__name__)

def _size(bounds):
    if not bounds:
        return (0,0)
    x1,y1,x2,y2 = bounds
    return (max(0, x2-x1), max(0, y2-y1))

def _is_interactive(e: ElementInfo) -> bool:
    if e.clickable is True:
        return True
    if (e.role == "button") and (e.enabled is not False):
        return True
    # android switch/checkbox
    if "Switch" in (e.class_name or "") or "CheckBox" in (e.class_name or ""):
        return True
    return False

def rule_missing_accessible_name(screen: ScreenCapture, levels: List[str]) -> List[Finding]:
    out: List[Finding] = []
    if "A" not in levels:
        return out
    idx = 0
    for e in screen.elements:
        if not _is_interactive(e):
            continue
        if e.enabled is False:
            continue
        name = e.accessible_name()
        if not name:
            idx += 1
            out.append(Finding(
                id=f"{screen.screen_id}-F-MAN-{idx:03d}",
                rule_id="missing_accessible_name",
                wcag="4.1.2",
                level="A",
                severity="critical",
                screen_id=screen.screen_id,
                fingerprint=screen.fingerprint,
                message="Interactive control is missing an accessible name (label/content-desc).",
                element_ref={"xpath": e.xpath, "resource_id": e.resource_id, "class": e.class_name, "bounds": e.bounds},
                evidence={"screenshot": os_rel(screen.screenshot_path), "hierarchy": os_rel(screen.hierarchy_path)},
            ))
    return out

def rule_hit_target_size(screen: ScreenCapture, min_size: int, levels: List[str]) -> List[Finding]:
    out: List[Finding] = []
    if "AA" not in levels:
        return out
    idx = 0
    for e in screen.elements:
        if not _is_interactive(e):
            continue
        w,h = _size(e.bounds)
        if w and h and (w < min_size or h < min_size):
            idx += 1
            out.append(Finding(
                id=f"{screen.screen_id}-F-HTS-{idx:03d}",
                rule_id="hit_target_too_small",
                wcag="2.5.8",
                level="AA",
                severity="major" if (w < min_size*0.75 or h < min_size*0.75) else "minor",
                screen_id=screen.screen_id,
                fingerprint=screen.fingerprint,
                message=f"Hit target is smaller than {min_size}x{min_size}px (found {w}x{h}).",
                element_ref={"xpath": e.xpath, "resource_id": e.resource_id, "class": e.class_name, "bounds": e.bounds},
                evidence={"screenshot": os_rel(screen.screenshot_path), "hierarchy": os_rel(screen.hierarchy_path)},
            ))
    return out

def rule_duplicate_labels(screen: ScreenCapture, levels: List[str]) -> List[Finding]:
    out: List[Finding] = []
    if "AA" not in levels:
        return out
    label_map: Dict[str, List[ElementInfo]] = {}
    for e in screen.elements:
        if not _is_interactive(e):
            continue
        name = e.accessible_name().strip().lower()
        if not name:
            continue
        label_map.setdefault(name, []).append(e)
    idx = 0
    for name, elems in label_map.items():
        if len(elems) >= 3:  # only flag noisy duplicates
            idx += 1
            out.append(Finding(
                id=f"{screen.screen_id}-F-DUP-{idx:03d}",
                rule_id="duplicate_labels",
                wcag="2.4.6",
                level="AA",
                severity="minor",
                screen_id=screen.screen_id,
                fingerprint=screen.fingerprint,
                message=f"Multiple controls share the same accessible name: '{name}'. Consider disambiguating.",
                element_ref={"examples": [{"xpath": e.xpath, "resource_id": e.resource_id, "class": e.class_name} for e in elems[:5]]},
                evidence={"screenshot": os_rel(screen.screenshot_path), "hierarchy": os_rel(screen.hierarchy_path)},
            ))
    return out

def rule_unfocusable_controls(screen: ScreenCapture, levels: List[str]) -> List[Finding]:
    out: List[Finding] = []
    if "A" not in levels:
        return out
    idx = 0
    for e in screen.elements:
        if e.clickable is True and e.focusable is False:
            idx += 1
            out.append(Finding(
                id=f"{screen.screen_id}-F-UFC-{idx:03d}",
                rule_id="unfocusable_control",
                wcag="2.1.1",
                level="A",
                severity="major",
                screen_id=screen.screen_id,
                fingerprint=screen.fingerprint,
                message="Control is clickable but not focusable; it may be unreachable by keyboard/screen reader.",
                element_ref={"xpath": e.xpath, "resource_id": e.resource_id, "class": e.class_name, "bounds": e.bounds, "focusable": e.focusable},
                evidence={"screenshot": os_rel(screen.screenshot_path), "hierarchy": os_rel(screen.hierarchy_path)},
            ))
    return out

def rule_modal_without_dismiss(screen: ScreenCapture, levels: List[str]) -> List[Finding]:
    out: List[Finding] = []
    if "A" not in levels:
        return out
    # Heuristic: detect a modal-like container and ensure a close/done/cancel button exists
    modal_tags = ("Alert", "Dialog", "Sheet", "Popup", "XCUIElementTypeAlert", "XCUIElementTypeSheet")
    has_modal = any(any(t in (e.class_name or "") for t in modal_tags) for e in screen.elements)
    if not has_modal:
        return out
    dismiss_words = ("close", "done", "cancel", "dismiss", "ok", "got it", "back")
    has_dismiss = False
    for e in screen.elements:
        if not _is_interactive(e):
            continue
        name = (e.accessible_name() or "").strip().lower()
        if any(w in name for w in dismiss_words):
            has_dismiss = True
            break
    if not has_dismiss:
        out.append(Finding(
            id=f"{screen.screen_id}-F-MOD-001",
            rule_id="modal_without_dismiss",
            wcag="2.1.2",
            level="A",
            severity="critical",
            screen_id=screen.screen_id,
            fingerprint=screen.fingerprint,
            message="Modal/dialog detected but no obvious dismiss action (Close/Done/Cancel) found.",
            element_ref={"modal_detected": True},
            evidence={"screenshot": os_rel(screen.screenshot_path), "hierarchy": os_rel(screen.hierarchy_path)},
        ))
    return out

def rule_text_truncation(screen: ScreenCapture, levels: List[str]) -> List[Finding]:
    out: List[Finding] = []
    if "AA" not in levels:
        return out
    idx = 0
    for e in screen.elements:
        txt = (e.text or e.raw.get("label") or "")
        if not isinstance(txt, str):
            continue
        t = txt.strip()
        if not t:
            continue
        # Ellipsis or obvious truncation marker
        if t.endswith("…") or t.endswith("..."):
            idx += 1
            out.append(Finding(
                id=f"{screen.screen_id}-F-TRN-{idx:03d}",
                rule_id="text_truncation",
                wcag="1.4.4",
                level="AA",
                severity="minor",
                screen_id=screen.screen_id,
                fingerprint=screen.fingerprint,
                message="Text appears truncated (ends with ellipsis). Consider supporting larger text/expanded layout.",
                element_ref={"xpath": e.xpath, "class": e.class_name, "text": t[:120], "bounds": e.bounds},
                evidence={"screenshot": os_rel(screen.screenshot_path), "hierarchy": os_rel(screen.hierarchy_path)},
            ))
    return out

def os_rel(path: str) -> str:
    # keep artifacts-relative paths stable in report
    # expects '.../artifacts/<run>/screens/...'
    parts = path.replace("\\", "/").split("/")
    if "artifacts" in parts:
        i = parts.index("artifacts")
        return "/".join(parts[i+1:])
    # fallback
    return path.replace("\\", "/")