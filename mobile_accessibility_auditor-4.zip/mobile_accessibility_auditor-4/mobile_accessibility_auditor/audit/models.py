from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

@dataclass
class Finding:
    id: str
    rule_id: str
    wcag: str
    level: str
    severity: str
    screen_id: str
    fingerprint: str
    message: str
    element_ref: Dict[str, Any]
    evidence: Dict[str, Any]
    ai_assisted: bool = False
    confidence: Optional[float] = None
    extra: Dict[str, Any] = field(default_factory=dict)
