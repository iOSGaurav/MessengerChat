from __future__ import annotations
from typing import Any, Dict, List
from .models import Finding
from .rules import (
    rule_missing_accessible_name,
    rule_hit_target_size,
    rule_duplicate_labels,
    rule_unfocusable_controls,
    rule_modal_without_dismiss,
    rule_text_truncation,
)
from .contrast import contrast_check_on_bounds
from ..explorer.models import ScreenCapture, ElementInfo
from ..utils.logging import get_logger

log = get_logger(__name__)

def run_rules(screens: List[ScreenCapture], audit_cfg: Dict[str, Any]) -> List[Finding]:
    levels = list(audit_cfg.get("levels", ["A","AA"]))
    min_target_size = int(audit_cfg.get("min_target_size", 44))
    findings: List[Finding] = []
    for s in screens:
        findings.extend(rule_missing_accessible_name(s, levels))
        findings.extend(rule_hit_target_size(s, min_target_size, levels))
        findings.extend(rule_duplicate_labels(s, levels))
        findings.extend(rule_unfocusable_controls(s, levels))
        findings.extend(rule_modal_without_dismiss(s, levels))
        findings.extend(rule_text_truncation(s, levels))

        # Optional contrast heuristic
        contrast_cfg = audit_cfg.get("contrast", {}) or {}
        if contrast_cfg.get("enabled") is True and "AA" in levels:
            min_ratio = float(audit_cfg.get("min_contrast_ratio", 4.5))
            idx = 0
            for e in s.elements:
                # Target text-like elements
                txt = (e.text or e.raw.get("label") or "")
                if not isinstance(txt, str) or not txt.strip():
                    continue
                if not e.bounds:
                    continue
                res = contrast_check_on_bounds(s.screenshot_path, e.bounds, min_ratio)
                if res:
                    idx += 1
                    findings.append(Finding(
                        id=f"{s.screen_id}-F-CNT-{idx:03d}",
                        rule_id="contrast_low",
                        wcag="1.4.3",
                        level="AA",
                        severity="major",
                        screen_id=s.screen_id,
                        fingerprint=s.fingerprint,
                        message=f"Estimated contrast ratio {res['ratio']:.2f} is below {min_ratio}.",
                        element_ref={"xpath": e.xpath, "class": e.class_name, "text": txt.strip()[:120], "bounds": e.bounds},
                        evidence={"screenshot": _rel(s.screenshot_path), "hierarchy": _rel(s.hierarchy_path)},
                        extra={"estimated_fg": res["fg"], "estimated_bg": res["bg"], "estimated_ratio": res["ratio"]}
                    ))
    return findings

def _rel(path: str) -> str:
    parts = path.replace("\\", "/").split("/")
    if "artifacts" in parts:
        i = parts.index("artifacts")
        return "/".join(parts[i+1:])
    return path.replace("\\", "/")
