from __future__ import annotations
from typing import List, Optional, Tuple, Dict, Any
from PIL import Image
import math

def _luminance(rgb) -> float:
    def f(c):
        c = c / 255.0
        return c/12.92 if c <= 0.03928 else ((c+0.055)/1.055) ** 2.4
    r,g,b = rgb
    return 0.2126*f(r) + 0.7152*f(g) + 0.0722*f(b)

def contrast_ratio(c1, c2) -> float:
    L1 = _luminance(c1)
    L2 = _luminance(c2)
    hi, lo = (L1, L2) if L1 >= L2 else (L2, L1)
    return (hi + 0.05) / (lo + 0.05)

def estimate_fg_bg_colors(img: Image.Image) -> Tuple[Tuple[int,int,int], Tuple[int,int,int]]:
    # K-means with k=2 on sampled pixels to separate foreground/background colors.
    # This is an approximation but deterministic and works reasonably for many UI text regions.
    small = img.convert("RGB")
    small = small.resize((max(10, small.width//4), max(10, small.height//4)))
    pixels = list(small.getdata())
    # Initialize centroids from corners and center
    c1 = pixels[0]
    c2 = pixels[len(pixels)//2]
    for _ in range(8):
        g1 = []
        g2 = []
        for p in pixels:
            d1 = (p[0]-c1[0])**2 + (p[1]-c1[1])**2 + (p[2]-c1[2])**2
            d2 = (p[0]-c2[0])**2 + (p[1]-c2[1])**2 + (p[2]-c2[2])**2
            (g1 if d1 <= d2 else g2).append(p)
        if not g1 or not g2:
            break
        def mean(g):
            return (sum(p[0] for p in g)//len(g), sum(p[1] for p in g)//len(g), sum(p[2] for p in g)//len(g))
        nc1, nc2 = mean(g1), mean(g2)
        if nc1 == c1 and nc2 == c2:
            break
        c1, c2 = nc1, nc2
    # Determine background as the cluster closer to the image border average
    border = []
    w,h = small.size
    for x in range(w):
        border.append(small.getpixel((x,0)))
        border.append(small.getpixel((x,h-1)))
    for y in range(h):
        border.append(small.getpixel((0,y)))
        border.append(small.getpixel((w-1,y)))
    border_mean = (sum(p[0] for p in border)//len(border), sum(p[1] for p in border)//len(border), sum(p[2] for p in border)//len(border))
    def dist(a,b):
        return (a[0]-b[0])**2+(a[1]-b[1])**2+(a[2]-b[2])**2
    bg = c1 if dist(c1, border_mean) <= dist(c2, border_mean) else c2
    fg = c2 if bg == c1 else c1
    return fg, bg

def contrast_check_on_bounds(screenshot_path: str, bounds: Tuple[int,int,int,int], min_ratio: float) -> Optional[Dict[str, Any]]:
    try:
        img = Image.open(screenshot_path)
    except Exception:
        return None
    x1,y1,x2,y2 = bounds
    x1 = max(0, min(img.width-1, x1))
    y1 = max(0, min(img.height-1, y1))
    x2 = max(1, min(img.width, x2))
    y2 = max(1, min(img.height, y2))
    if x2 <= x1 or y2 <= y1:
        return None
    crop = img.crop((x1,y1,x2,y2))
    fg, bg = estimate_fg_bg_colors(crop)
    ratio = contrast_ratio(fg, bg)
    if ratio < min_ratio:
        return {"ratio": ratio, "fg": fg, "bg": bg}
    return None
