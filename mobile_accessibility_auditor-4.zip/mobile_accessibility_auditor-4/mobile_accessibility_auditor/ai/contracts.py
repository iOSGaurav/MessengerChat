from __future__ import annotations
from typing import Any, Dict, List, Optional, Protocol
from pydantic import BaseModel, Field

class AILabelSuggestion(BaseModel):
    xpath: str
    current_label: str
    quality: str  # good | poor | missing
    suggested_label: Optional[str] = None
    rationale: Optional[str] = None
    confidence: float = Field(ge=0.0, le=1.0)

class AIRemediationSuggestion(BaseModel):
    rule_id: str
    platform: str
    suggestion: str
    code_snippet: Optional[str] = None
    confidence: float = Field(ge=0.0, le=1.0)

class AIFocusOrderNote(BaseModel):
    screen_id: str
    note: str
    confidence: float = Field(ge=0.0, le=1.0)

class AccessibilityAIProvider(Protocol):
    async def analyze_labels(self, *, platform: str, screen_id: str, elements: List[Dict[str, Any]]) -> List[AILabelSuggestion]: ...
    async def generate_remediation(self, *, platform: str, finding: Dict[str, Any]) -> List[AIRemediationSuggestion]: ...
    async def analyze_focus_order(self, *, platform: str, screen_id: str, elements: List[Dict[str, Any]]) -> List[AIFocusOrderNote]: ...
