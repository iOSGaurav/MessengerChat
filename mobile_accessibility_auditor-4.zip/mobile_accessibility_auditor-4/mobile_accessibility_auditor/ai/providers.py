from __future__ import annotations
import os
import json
from typing import Any, Dict, List, Optional
import httpx
from .contracts import AccessibilityAIProvider, AILabelSuggestion, AIRemediationSuggestion, AIFocusOrderNote
from ..utils.redact import redact_any_strings_in_obj

class NoneProvider:
    async def analyze_labels(self, *, platform: str, screen_id: str, elements: List[Dict[str, Any]]) -> List[AILabelSuggestion]:
        return []
    async def generate_remediation(self, *, platform: str, finding: Dict[str, Any]) -> List[AIRemediationSuggestion]:
        return []
    async def analyze_focus_order(self, *, platform: str, screen_id: str, elements: List[Dict[str, Any]]) -> List[AIFocusOrderNote]:
        return []

class OpenAIProvider:
    def __init__(self, model: str, timeout_seconds: int):
        self.model = model
        self.timeout = timeout_seconds
        self.api_key = os.getenv("OPENAI_API_KEY", "")
        if not self.api_key:
            raise RuntimeError("OPENAI_API_KEY not set")
        self.base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")

    async def _chat_json(self, system: str, user: str, schema_hint: str) -> Any:
        headers = {"Authorization": f"Bearer {self.api_key}"}
        payload = {
            "model": self.model,
            "response_format": {"type":"json_object"},
            "messages": [
                {"role":"system","content": system},
                {"role":"user","content": user + "\n\nReturn ONLY valid JSON. Schema hint:\n" + schema_hint},
            ],
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(f"{self.base_url}/chat/completions", headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
            content = data["choices"][0]["message"]["content"]
            return json.loads(content)

    async def analyze_labels(self, *, platform: str, screen_id: str, elements: List[Dict[str, Any]]) -> List[AILabelSuggestion]:
        system = "You are an accessibility assistant. You must output strict JSON only."
        user = json.dumps({"platform": platform, "screen_id": screen_id, "elements": elements[:80]})
        schema = '{"suggestions":[{"xpath":"string","current_label":"string","quality":"good|poor|missing","suggested_label":"string|null","rationale":"string|null","confidence":0.0}]}'
        data = await self._chat_json(system, user, schema)
        out = []
        for s in data.get("suggestions", []):
            out.append(AILabelSuggestion.model_validate(s))
        return out

    async def generate_remediation(self, *, platform: str, finding: Dict[str, Any]) -> List[AIRemediationSuggestion]:
        system = "You are a senior mobile accessibility engineer. Output strict JSON only."
        user = json.dumps({"platform": platform, "finding": finding})
        schema = '{"remediations":[{"rule_id":"string","platform":"string","suggestion":"string","code_snippet":"string|null","confidence":0.0}]}'
        data = await self._chat_json(system, user, schema)
        out = []
        for s in data.get("remediations", []):
            out.append(AIRemediationSuggestion.model_validate(s))
        return out

    async def analyze_focus_order(self, *, platform: str, screen_id: str, elements: List[Dict[str, Any]]) -> List[AIFocusOrderNote]:
        system = "You are an accessibility assistant. Output strict JSON only."
        user = json.dumps({"platform": platform, "screen_id": screen_id, "elements": elements[:120]})
        schema = '{"notes":[{"screen_id":"string","note":"string","confidence":0.0}]}'
        data = await self._chat_json(system, user, schema)
        out = []
        for n in data.get("notes", []):
            out.append(AIFocusOrderNote.model_validate(n))
        return out

class OllamaProvider:
    def __init__(self, model: str, timeout_seconds: int, host: str = "http://127.0.0.1:11434"):
        self.model = model
        self.timeout = timeout_seconds
        self.host = host

    async def _call(self, prompt: str) -> Any:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(f"{self.host}/api/generate", json={"model": self.model, "prompt": prompt, "stream": False, "format":"json"})
            r.raise_for_status()
            data = r.json()
            # Ollama returns text in 'response'
            import json as _json
            return _json.loads(data.get("response","{}"))

    async def analyze_labels(self, *, platform: str, screen_id: str, elements: List[Dict[str, Any]]) -> List[AILabelSuggestion]:
        schema = '{"suggestions":[{"xpath":"string","current_label":"string","quality":"good|poor|missing","suggested_label":"string|null","rationale":"string|null","confidence":0.0}]}'
        prompt = "Analyze labels for accessibility. Return strict JSON only matching: " + schema + "\nInput: " + json.dumps({"platform":platform,"screen_id":screen_id,"elements":elements[:80]})
        data = await self._call(prompt)
        return [AILabelSuggestion.model_validate(s) for s in data.get("suggestions", [])]

    async def generate_remediation(self, *, platform: str, finding: Dict[str, Any]) -> List[AIRemediationSuggestion]:
        schema = '{"remediations":[{"rule_id":"string","platform":"string","suggestion":"string","code_snippet":"string|null","confidence":0.0}]}'
        prompt = "Provide remediation suggestions. Return strict JSON only matching: " + schema + "\nInput: " + json.dumps({"platform":platform,"finding":finding})
        data = await self._call(prompt)
        return [AIRemediationSuggestion.model_validate(s) for s in data.get("remediations", [])]

    async def analyze_focus_order(self, *, platform: str, screen_id: str, elements: List[Dict[str, Any]]) -> List[AIFocusOrderNote]:
        schema = '{"notes":[{"screen_id":"string","note":"string","confidence":0.0}]}'
        prompt = "Analyze focus order issues. Return strict JSON only matching: " + schema + "\nInput: " + json.dumps({"platform":platform,"screen_id":screen_id,"elements":elements[:120]})
        data = await self._call(prompt)
        return [AIFocusOrderNote.model_validate(n) for n in data.get("notes", [])]

def build_ai_provider(ai_cfg: Dict[str, Any]) -> AccessibilityAIProvider:
    if not ai_cfg.get("enabled", False):
        return NoneProvider()
    provider = (ai_cfg.get("provider") or "none").lower()
    model = ai_cfg.get("model") or "gpt-4o-mini"
    timeout = int(ai_cfg.get("timeout_seconds", 20))
    if provider == "openai" or provider == "azure":
        return OpenAIProvider(model=model, timeout_seconds=timeout)
    if provider == "ollama":
        host = ai_cfg.get("host") or "http://127.0.0.1:11434"
        return OllamaProvider(model=model, timeout_seconds=timeout, host=host)
    return NoneProvider()

def maybe_redact(ai_cfg: Dict[str, Any], obj: Any) -> Any:
    privacy = ai_cfg.get("privacy", {}) or {}
    if privacy.get("redact_sensitive_text", True):
        return redact_any_strings_in_obj(obj)
    return obj
