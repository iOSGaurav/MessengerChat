from __future__ import annotations
import sys
import json
from typing import Any, Dict, Optional
import yaml

from .utils.logging import setup_logging, get_logger
from .environment import check_appium, check_android, check_ios
from .runner import load_config, run_audit_from_config
from .config import RootConfig
from .drivers.factory import build_driver

log = get_logger(__name__)

def validate_environment(params: Dict[str, Any]) -> Dict[str, Any]:
    server = params.get("appium_server_url") or "http://127.0.0.1:4723"
    out = {
        "appium": check_appium(server),
        "android": check_android(),
        "ios": check_ios(),
    }
    return out

def list_targets(params: Dict[str, Any]) -> Dict[str, Any]:
    # Build minimal configs to leverage driver list_targets
    server = params.get("appium_server_url") or "http://127.0.0.1:4723"
    platform = params.get("platform") or "android"
    scaffold = {"platform": platform, "appium_server_url": server, "app": {"method": "package_activity" if platform=="android" else "bundleId"}}
    cfg = RootConfig.model_validate(scaffold)
    drv = build_driver(cfg)
    return drv.list_targets()

def run_audit(params: Dict[str, Any]) -> Dict[str, Any]:
    # params can include config dict OR config_path
    if "config" in params and isinstance(params["config"], dict):
        cfg = RootConfig.model_validate(params["config"])
    else:
        config_path = params.get("config_path")
        if not config_path:
            raise ValueError("run_audit requires either 'config' dict or 'config_path'")
        cfg = load_config(config_path)
    # Run non-interactive by default for MCP.
    return run_audit_from_config(cfg, interactive=False)

def _handle_request(req: Dict[str, Any]) -> Dict[str, Any]:
    method = req.get("method")
    params = req.get("params") or {}
    if method == "validate_environment":
        return {"result": validate_environment(params)}
    if method == "list_targets":
        return {"result": list_targets(params)}
    if method == "run_audit":
        return {"result": run_audit(params)}
    raise ValueError(f"Unknown method: {method}")

def main() -> None:
    setup_logging()
    # Simple stdio JSON-RPC line protocol
    # Input: one JSON object per line: {"id":"1","method":"validate_environment","params":{...}}
    # Output: {"id":"1","ok":true,"result":{...}} or {"id":"1","ok":false,"error":"..."}
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            req_id = req.get("id")
            resp = _handle_request(req)
            out = {"id": req_id, "ok": True, **resp}
        except Exception as e:
            out = {"id": req.get("id") if isinstance(req, dict) else None, "ok": False, "error": str(e)}
        sys.stdout.write(json.dumps(out) + "\n")
        sys.stdout.flush()

if __name__ == "__main__":
    main()
