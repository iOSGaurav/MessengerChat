from __future__ import annotations
import argparse
import os
import sys
import yaml
from typing import Any, Dict, Optional

from .utils.logging import setup_logging, get_logger
from .config import RootConfig
from .runner import load_config, run_audit_from_config
from .environment import check_appium, check_android, check_ios
from .drivers.factory import build_driver

log = get_logger(__name__)

def _prompt_choice(title: str, options: list[str]) -> int:
    print("\n" + title)
    for i, opt in enumerate(options, start=1):
        print(f"  {i}. {opt}")
    while True:
        try:
            s = input("Choose: ").strip()
        except EOFError:
            raise RuntimeError("No interactive stdin available (EOF). Run with --ci and provide --config, or run in an interactive terminal.")
        try:
            idx = int(s)
            if 1 <= idx <= len(options):
                return idx - 1
        except Exception:
            pass
        print("Invalid choice. Try again.")

def _interactive_select_platform() -> str:
    idx = _prompt_choice("Select platform", ["Android", "iOS"])
    return "android" if idx == 0 else "ios"

def _interactive_select_target(cfg: RootConfig) -> RootConfig:
    drv = build_driver(cfg)
    targets = drv.list_targets()
    if cfg.platform == "android":
        devs = targets.get("android", {}).get("devices", [])
        opts = [d.get("raw") or d.get("udid") for d in devs]
        if not opts:
            raise RuntimeError("No Android devices/emulators found (adb devices).")
        idx = _prompt_choice("Select Android device/emulator", opts)
        cfg.targets.android.device_udid = devs[idx].get("udid")
    else:
        # Prefer booted simulators first
        simctl = targets.get("ios", {}).get("simctl", {}).get("devices", {})
        sims = []
        if isinstance(simctl, dict):
            for runtime, items in simctl.items():
                for it in items:
                    sims.append({"name": it.get("name"), "udid": it.get("udid"), "state": it.get("state"), "runtime": runtime})
        opts = [f"{s['name']} | {s['state']} | {s['udid']} | {s['runtime']}" for s in sims]
        if not opts:
            # fallback to xctrace raw list
            xct = targets.get("ios", {}).get("xctrace_devices", [])
            opts = [d.get("raw","") for d in xct]
            if not opts:
                raise RuntimeError("No iOS targets found.")
            idx = _prompt_choice("Select iOS device (xctrace)", opts)
            # Cannot reliably parse UDID; ask user
            udid = input("Enter UDID from the selected line (inside parentheses): ").strip()
            cfg.targets.ios.udid = udid
        else:
            idx = _prompt_choice("Select iOS simulator/device", opts)
            cfg.targets.ios.udid = sims[idx].get("udid")
            cfg.targets.ios.device_name = sims[idx].get("name")
    return cfg

def _interactive_app_details(cfg: RootConfig) -> RootConfig:
    if cfg.platform == "android":
        idx = _prompt_choice("Android app launch method", ["package_activity (installed app)", "apk (install apk)"])
        if idx == 0:
            cfg.app.method = "package_activity"
            if not cfg.app.appPackage:
                cfg.app.appPackage = input("appPackage: ").strip()
            if not cfg.app.appActivity:
                cfg.app.appActivity = input("appActivity: ").strip()
        else:
            cfg.app.method = "apk"
            cfg.app.apkPath = input("Path to .apk: ").strip()
    else:
        idx = _prompt_choice("iOS app launch method", ["bundleId (installed app)", ".app", ".ipa"])
        if idx == 0:
            cfg.app.method = "bundleId"
            if not cfg.app.bundleId:
                cfg.app.bundleId = input("bundleId: ").strip()
        elif idx == 1:
            cfg.app.method = "app"
            cfg.app.appPath = input("Path to .app: ").strip()
        else:
            cfg.app.method = "ipa"
            cfg.app.ipaPath = input("Path to .ipa: ").strip()
    return cfg

def _interactive_login(cfg: RootConfig) -> RootConfig:
    idx = _prompt_choice("Login/onboarding strategy", ["Manual (pause until READY)", "Seed steps JSON", "Deep link / intent"])
    if idx == 0:
        cfg.login.strategy = "manual"
        prompt = input("Manual prompt (optional, press Enter to keep default): ").strip()
        if prompt:
            cfg.login.manual_prompt = prompt
    elif idx == 1:
        cfg.login.strategy = "seed_steps"
        cfg.login.seed_steps_path = input("Path to seed steps JSON: ").strip()
    else:
        cfg.login.strategy = "deeplink"
        cfg.login.deeplink_url = input("Deep link URL: ").strip()
    return cfg

def _interactive_limits(cfg: RootConfig) -> RootConfig:
    print("\nExploration limits (press Enter to keep defaults)")
    def ask_int(label: str, cur: int) -> int:
        s = input(f"{label} [{cur}]: ").strip()
        return int(s) if s else cur
    cfg.exploration.max_screens = ask_int("max_screens", cfg.exploration.max_screens)
    cfg.exploration.max_depth = ask_int("max_depth", cfg.exploration.max_depth)
    cfg.exploration.per_screen_action_budget = ask_int("per_screen_action_budget", cfg.exploration.per_screen_action_budget)
    cfg.exploration.global_time_budget_minutes = ask_int("global_time_budget_minutes", cfg.exploration.global_time_budget_minutes)
    return cfg

def _interactive_safe_mode(cfg: RootConfig) -> RootConfig:
    s = input(f"Safe mode (y/n) [y]: ").strip().lower()
    cfg.safety.safe_mode = (s != "n")
    if cfg.safety.safe_mode:
        print("Denylist keywords (comma separated), or Enter to keep:")
        s2 = input(", ".join(cfg.safety.denylist_keywords) + "\n> ").strip()
        if s2:
            cfg.safety.denylist_keywords = [x.strip() for x in s2.split(",") if x.strip()]
    return cfg

def main(argv: Optional[list[str]] = None) -> None:
    setup_logging(os.getenv("LOG_LEVEL", "INFO"))
    p = argparse.ArgumentParser(prog="mobile_accessibility_auditor")
    p.add_argument("--config", help="Path to config YAML")
    p.add_argument("--ci", action="store_true", help="Non-interactive CI mode")
    p.add_argument("--platform", choices=["android","ios"], help="Override platform")
    args = p.parse_args(argv)

    # Auto-detect non-interactive environments
    if not args.ci and not sys.stdin.isatty():
        if args.config:
            args.ci = True
        else:
            raise RuntimeError("Non-interactive stdin detected. Provide --config and --ci, or run in an interactive terminal.")

    if args.config:
        cfg = load_config(args.config)
    else:
        # minimal config scaffold for interactive
        platform = args.platform or _interactive_select_platform()
        scaffold = {
            "platform": platform,
            "appium_server_url": "http://127.0.0.1:4723",
            "app": {"method": "package_activity" if platform=="android" else "bundleId"},
        }
        cfg = RootConfig.model_validate(scaffold)

    if args.platform:
        cfg.platform = args.platform  # type: ignore

    # Environment checks
    appium_check = check_appium(cfg.appium_server_url)
    if not appium_check.get("ok"):
        print("Appium check failed:", appium_check)
        if args.ci:
            sys.exit(2)
    if cfg.platform == "android":
        andr = check_android()
        if not andr.get("adb", {}).get("ok"):
            print("Android environment check failed:", andr)
            if args.ci:
                sys.exit(2)
    else:
        ios = check_ios()
        if not ios.get("xcode_select", {}).get("ok"):
            print("iOS environment check failed:", ios)
            if args.ci:
                sys.exit(2)

    if not args.ci:
        cfg = _interactive_select_target(cfg)
        cfg = _interactive_app_details(cfg)
        cfg = _interactive_login(cfg)
        cfg = _interactive_limits(cfg)
        cfg = _interactive_safe_mode(cfg)

    res = run_audit_from_config(cfg, interactive=(not args.ci))
    # Print minimal machine-readable output
    print("\nAUDIT_RESULT_JSON_BEGIN")
    import json
    print(json.dumps(res, indent=2))
    print("AUDIT_RESULT_JSON_END")

if __name__ == "__main__":
    main()
