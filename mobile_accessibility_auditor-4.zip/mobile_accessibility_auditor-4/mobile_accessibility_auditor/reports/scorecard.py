from __future__ import annotations
from typing import Any, Dict, List
from collections import defaultdict

def build_scorecard(report: Dict[str, Any]) -> Dict[str, Any]:
    findings = report.get("findings", [])
    by_sev = defaultdict(int)
    by_wcag = defaultdict(int)
    by_rule = defaultdict(int)
    for f in findings:
        by_sev[f.get("severity", "unknown")] += 1
        by_wcag[f.get("wcag", "unknown")] += 1
        by_rule[f.get("rule_id", "unknown")] += 1
    return {
        "screens_visited": report.get("summary", {}).get("screens_visited", 0),
        "findings_total": len(findings),
        "by_severity": dict(by_sev),
        "by_wcag": dict(by_wcag),
        "by_rule": dict(by_rule),
    }
