from __future__ import annotations
from typing import Any, Dict, List
from ..explorer.models import ScreenCapture
from ..voiceover.rotor import rotor_presence_assertions
from ..voiceover.synthesis import synthesize_screen_announcements

def generate_vpat_voiceover_evidence(run_meta: Dict[str, Any], screens: List[ScreenCapture]) -> str:
    lines: List[str] = []
    lines.append("# VPAT Appendix: VoiceOver Evidence\n")
    lines.append("This appendix summarizes VoiceOver-relevant evidence derived from the iOS accessibility tree and captured artifacts.\n")
    lines.append("## Test environment")
    lines.append(f"- Platform: {run_meta.get('platform')}")
    lines.append(f"- Device: {run_meta.get('device')}")
    lines.append(f"- App: {run_meta.get('app')}\n")
    lines.append("## Evidence per screen")
    for s in screens:
        lines.append(f"---\n### {s.screen_id}")
        lines.append(f"- Fingerprint: `{s.fingerprint}`")
        lines.append(f"- Screenshot: `{_rel(s.screenshot_path)}`")
        lines.append(f"- Accessibility hierarchy: `{_rel(s.hierarchy_path)}`")
        assertions = rotor_presence_assertions(s.elements)
        lines.append("- Rotor categories inferred/expected:")
        if assertions:
            for a in assertions:
                lines.append(f"  - {a['category']} (expected) — {a['reason']}")
        else:
            lines.append("  - None inferred.")
        anns = synthesize_screen_announcements(s.elements, limit=15)
        lines.append("- Sample expected announcements (synthesized):")
        if anns:
            for a in anns:
                lines.append(f"  - {a['announcement']} (xpath: `{a['xpath']}`)")
        else:
            lines.append("  - None.")
    lines.append("\n## Notes / Limitations")
    lines.append("- Rotor availability is OS/context-dependent; expectations are inferred from semantic cues in the accessibility tree.")
    lines.append("- Spoken synthesis is deterministic and may differ slightly from iOS phrasing; use as an expected baseline for manual verification.")
    return "\n".join(lines)

def _rel(path: str) -> str:
    p = path.replace('\\\\','/').split('/')
    if 'artifacts' in p:
        i = p.index('artifacts')
        return '/'.join(p[i+1:])
    return path.replace('\\\\','/')
