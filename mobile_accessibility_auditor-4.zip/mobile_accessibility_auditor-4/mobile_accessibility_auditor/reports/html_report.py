from __future__ import annotations
import os
from typing import Any, Dict
from jinja2 import Environment, FileSystemLoader, select_autoescape
from ..utils.fs import write_text, ensure_dir

def render_html_report(data: Dict[str, Any], output_path: str, templates_dir: str) -> None:
    ensure_dir(os.path.dirname(output_path))
    env = Environment(
        loader=FileSystemLoader(templates_dir),
        autoescape=select_autoescape(["html", "xml"]),
    )
    tpl = env.get_template("report.html.j2")
    html = tpl.render(
        run=data.get("run", {}),
        summary=data.get("summary", {}),
        findings=data.get("findings", []),
        ai_findings=data.get("ai_findings", []),
        voiceover=data.get("voiceover"),
        screens=data.get("screens", []),
        transitions=data.get("transitions", []),
        errors=data.get("errors", []),
    )
    write_text(output_path, html)
