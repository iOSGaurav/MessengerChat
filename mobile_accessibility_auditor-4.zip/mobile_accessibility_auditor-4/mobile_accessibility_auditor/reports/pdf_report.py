from __future__ import annotations
import os
from typing import Any, Dict, List
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from ..utils.fs import ensure_dir

def render_pdf_report(data: Dict[str, Any], output_path: str) -> None:
    ensure_dir(os.path.dirname(output_path))
    c = canvas.Canvas(output_path, pagesize=letter)
    width, height = letter
    y = height - 0.8*inch

    run = data.get("run", {})
    summary = data.get("summary", {})
    findings = data.get("findings", [])

    c.setFont("Helvetica-Bold", 16)
    c.drawString(0.8*inch, y, "Mobile Accessibility Audit Report")
    y -= 0.4*inch

    c.setFont("Helvetica", 10)
    meta = f"Tool: {run.get('tool')} v{run.get('version')} | Platform: {run.get('platform')} | Started: {run.get('started_at')} | Finished: {run.get('finished_at')}"
    c.drawString(0.8*inch, y, meta[:120])
    y -= 0.3*inch

    c.setFont("Helvetica-Bold", 12)
    c.drawString(0.8*inch, y, "Summary")
    y -= 0.2*inch
    c.setFont("Helvetica", 10)
    lines = [
        f"Screens visited: {summary.get('screens_visited', 0)}",
        f"Total findings: {summary.get('findings_total', 0)}",
        f"Severities: critical={summary.get('by_severity', {}).get('critical', 0)}, major={summary.get('by_severity', {}).get('major', 0)}, minor={summary.get('by_severity', {}).get('minor', 0)}",
    ]
    for line in lines:
        c.drawString(0.9*inch, y, line)
        y -= 0.18*inch

    y -= 0.1*inch
    c.setFont("Helvetica-Bold", 12)
    c.drawString(0.8*inch, y, "Findings (top)")
    y -= 0.2*inch

    c.setFont("Helvetica", 9)
    for f in findings[:60]:
        text = f"[{f.get('severity')}] WCAG {f.get('wcag')} ({f.get('level')}) {f.get('rule_id')} on {f.get('screen_id')}: {f.get('message')}"
        for chunk in _wrap(text, 110):
            if y < 0.8*inch:
                c.showPage()
                y = height - 0.8*inch
                c.setFont("Helvetica", 9)
            c.drawString(0.8*inch, y, chunk)
            y -= 0.14*inch
        y -= 0.06*inch

    c.save()

def _wrap(s: str, n: int) -> List[str]:
    out = []
    cur = ""
    for w in s.split():
        if len(cur) + len(w) + 1 > n:
            out.append(cur)
            cur = w
        else:
            cur = w if not cur else cur + " " + w
    if cur:
        out.append(cur)
    return out
