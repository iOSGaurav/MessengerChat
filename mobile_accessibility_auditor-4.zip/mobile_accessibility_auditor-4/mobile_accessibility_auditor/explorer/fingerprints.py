from __future__ import annotations
from typing import List
from ..utils.hashing import stable_hash_parts
from .models import ElementInfo

def fingerprint_screen(platform: str, elements: List[ElementInfo], page_source: str) -> str:
    # Use a stable subset of attributes to hash.
    parts: List[str] = [platform]
    # Normalize elements: keep only first N to limit size, sorted for determinism
    norm = []
    for e in elements:
        name = e.accessible_name()
        rid = e.resource_id or ""
        b = e.bounds or (0,0,0,0)
        role = e.role or ""
        clickable = "1" if e.clickable else "0"
        norm.append((role, e.class_name or "", rid, name, clickable, b))
    norm.sort(key=lambda t: (t[0], t[1], t[2], t[3], t[4], t[5]))
    for t in norm[:250]:
        parts.append("|".join([str(x) for x in t]))
    # Add a small hash of raw page_source length + checksum to reduce collisions
    parts.append(str(len(page_source)))
    parts.append(page_source[:2000])  # bounded
    return stable_hash_parts(parts)
