from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple
import xml.etree.ElementTree as ET
from .models import ElementInfo

def _parse_bounds_android(bounds: str) -> Optional[Tuple[int,int,int,int]]:
    # format: [x1,y1][x2,y2]
    try:
        parts = bounds.replace("][", ",").replace("[", "").replace("]", "").split(",")
        x1,y1,x2,y2 = map(int, parts)
        return (x1,y1,x2,y2)
    except Exception:
        return None

def _parse_frame_ios(x: str, y: str, w: str, h: str) -> Optional[Tuple[int,int,int,int]]:
    try:
        x1 = int(float(x)); y1 = int(float(y))
        ww = int(float(w)); hh = int(float(h))
        return (x1, y1, x1+ww, y1+hh)
    except Exception:
        return None

def parse_hierarchy(platform: str, xml_text: str) -> List[ElementInfo]:
    elements: List[ElementInfo] = []
    try:
        root = ET.fromstring(xml_text)
    except Exception:
        return elements

    # Pre-order traversal with xpath generation
    def walk(node: ET.Element, path: str):
        children = list(node)
        tag = node.tag
        idx = 1
        if node is not root:
            # determine index among same-tag siblings
            pass

        # Build an xpath-ish path with position indices
        # Note: ET doesn't easily give sibling position; we approximate using running indices per tag per parent.
        yield node, path

        # count siblings per tag
        counters: Dict[str, int] = {}
        for child in children:
            t = child.tag
            counters[t] = counters.get(t, 0) + 1
        seen: Dict[str, int] = {}
        for child in children:
            t = child.tag
            seen[t] = seen.get(t, 0) + 1
            child_path = f"{path}/{t}[{seen[t]}]"
            yield from walk(child, child_path)

    for node, xpath in walk(root, f"/{root.tag}[1]"):
        attrib = dict(node.attrib)
        class_name = attrib.get("class") or attrib.get("type") or node.tag
        resource_id = attrib.get("resource-id") or attrib.get("name") or attrib.get("identifier")
        text = attrib.get("text") or attrib.get("label") or attrib.get("value")
        content_desc = attrib.get("content-desc") or attrib.get("contentDescription") or attrib.get("name") or attrib.get("label")

        enabled = attrib.get("enabled")
        if enabled is not None:
            enabled = enabled in ("true", "1", "True", "YES", "Yes")
        clickable = attrib.get("clickable")
        if clickable is not None:
            clickable = clickable in ("true", "1", "True", "YES", "Yes")
        focusable = attrib.get("focusable")
        if focusable is not None:
            focusable = focusable in ("true", "1", "True", "YES", "Yes")

        bounds = None
        if platform == "android":
            if attrib.get("bounds"):
                bounds = _parse_bounds_android(attrib.get("bounds",""))
        else:
            # iOS page source commonly has x/y/width/height
            if all(k in attrib for k in ("x","y","width","height")):
                bounds = _parse_frame_ios(attrib["x"], attrib["y"], attrib["width"], attrib["height"])

        # Role heuristic
        role = None
        if platform == "android":
            if "Button" in class_name or class_name.endswith(".Button"):
                role = "button"
            elif "EditText" in class_name or "TextField" in class_name:
                role = "textbox"
            elif "ImageView" in class_name:
                role = "image"
        else:
            if "Button" in class_name:
                role = "button"
            elif "TextField" in class_name or "SecureTextField" in class_name:
                role = "textbox"
            elif "Image" in class_name:
                role = "image"

        # Determine interactive heuristic
        if clickable is None:
            clickable = attrib.get("clickable") in ("true","1","True") if "clickable" in attrib else None

        elements.append(ElementInfo(
            xpath=xpath,
            class_name=class_name,
            resource_id=resource_id,
            text=text,
            content_desc=content_desc,
            enabled=enabled,
            clickable=clickable,
            focusable=focusable,
            bounds=bounds,
            role=role,
            raw=attrib
        ))
    return elements
