from __future__ import annotations
from typing import List, Optional, Set, Tuple
from .models import ElementInfo, Action

def is_risky_label(label: str, denylist_keywords: List[str]) -> bool:
    ll = (label or "").strip().lower()
    if not ll:
        return False
    for k in denylist_keywords:
        if k.lower() in ll:
            return True
    return False

def candidate_tappable_elements(elements: List[ElementInfo]) -> List[ElementInfo]:
    cands = []
    for e in elements:
        if e.clickable is True:
            cands.append(e)
        else:
            # iOS sometimes doesn't provide clickable; use role heuristics
            if e.role in ("button",) and e.enabled is not False:
                cands.append(e)
    # Prefer elements with a name
    cands.sort(key=lambda e: (0 if e.accessible_name() else 1, 0 if (e.bounds and (e.bounds[2]-e.bounds[0])*(e.bounds[3]-e.bounds[1])>0) else 1))
    return cands

def build_actions_for_screen(elements: List[ElementInfo], denylist_keywords: List[str], safe_mode: bool, max_actions: int, already_used_xpaths: Set[str]) -> List[Action]:
    actions: List[Action] = []
    for idx, e in enumerate(candidate_tappable_elements(elements)):
        if len(actions) >= max_actions:
            break
        if e.xpath in already_used_xpaths:
            continue
        label = e.accessible_name() or ""
        if safe_mode and is_risky_label(label, denylist_keywords):
            continue
        actions.append(Action(
            action_id=f"A-{idx:04d}",
            kind="tap",
            element_xpath=e.xpath,
            element_label=label[:80] if label else None,
            meta={"resource_id": e.resource_id, "class": e.class_name, "bounds": e.bounds}
        ))
    return actions
