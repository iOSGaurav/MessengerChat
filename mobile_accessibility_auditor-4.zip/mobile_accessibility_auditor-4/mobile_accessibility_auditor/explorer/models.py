from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

@dataclass
class ElementInfo:
    xpath: str
    class_name: str
    resource_id: Optional[str]
    text: Optional[str]
    content_desc: Optional[str]
    enabled: Optional[bool]
    clickable: Optional[bool]
    focusable: Optional[bool]
    bounds: Optional[Tuple[int,int,int,int]]
    role: Optional[str] = None
    raw: Dict[str, Any] = field(default_factory=dict)

    def accessible_name(self) -> str:
        for v in [self.content_desc, self.text, self.raw.get("label"), self.raw.get("name"), self.raw.get("value")]:
            if isinstance(v, str) and v.strip():
                return v.strip()
        return ""

@dataclass
class ScreenCapture:
    screen_id: str
    fingerprint: str
    depth: int
    url_or_activity: Optional[str]
    screenshot_path: str
    hierarchy_path: str
    elements: List[ElementInfo]
    meta: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Action:
    action_id: str
    kind: str  # tap | back | swipe
    element_xpath: Optional[str] = None
    element_label: Optional[str] = None
    meta: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Transition:
    from_fingerprint: str
    to_fingerprint: str
    action: Action
