from __future__ import annotations
import os
import time
from typing import Any, Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field

from ..utils.logging import get_logger
from ..utils.fs import ensure_dir, write_text
from ..utils.time import Budget
from .models import ScreenCapture, Action, Transition
from .parser import parse_hierarchy
from .fingerprints import fingerprint_screen
from .actions import build_actions_for_screen

log = get_logger(__name__)

@dataclass
class ExplorationResult:
    screens: List[ScreenCapture] = field(default_factory=list)
    transitions: List[Transition] = field(default_factory=list)
    errors: List[Dict[str, Any]] = field(default_factory=list)

class Explorer:
    def __init__(self, platform: str, driver, artifacts_dir: str, exploration_cfg: Dict[str, Any], safety_cfg: Dict[str, Any]):
        self.platform = platform
        self.driver = driver
        self.artifacts_dir = artifacts_dir
        self.screens_dir = os.path.join(artifacts_dir, "screens")
        ensure_dir(self.screens_dir)
        self.max_screens = int(exploration_cfg.get("max_screens", 60))
        self.max_depth = int(exploration_cfg.get("max_depth", 10))
        self.per_screen_action_budget = int(exploration_cfg.get("per_screen_action_budget", 35))
        self.budget = Budget.from_minutes(float(exploration_cfg.get("global_time_budget_minutes", 20)))
        self.safe_mode = bool(safety_cfg.get("safe_mode", True))
        self.denylist = list(safety_cfg.get("denylist_keywords", []))

        self.visited: Set[str] = set()
        self.used_actions: Dict[str, Set[str]] = {}  # fingerprint -> set(xpath)

    def capture_screen(self, screen_id: str, depth: int) -> ScreenCapture:
        xml = self.driver.page_source
        elements = parse_hierarchy(self.platform, xml)
        fp = fingerprint_screen(self.platform, elements, xml)
        screenshot_path = os.path.join(self.screens_dir, f"{screen_id}.png")
        hierarchy_path = os.path.join(self.screens_dir, f"{screen_id}.xml")
        # Save artifacts
        try:
            self.driver.get_screenshot_as_file(screenshot_path)
        except Exception as e:
            log.warning("screenshot failed: %s", e)
        write_text(hierarchy_path, xml)
        url_or_activity = None
        # Best-effort current activity/name (platform-specific)
        try:
            if self.platform == "android":
                url_or_activity = self.driver.current_activity  # type: ignore
            else:
                url_or_activity = self.driver.execute_script("mobile: activeAppInfo")  # type: ignore
        except Exception:
            pass
        return ScreenCapture(
            screen_id=screen_id,
            fingerprint=fp,
            depth=depth,
            url_or_activity=str(url_or_activity) if url_or_activity is not None else None,
            screenshot_path=screenshot_path,
            hierarchy_path=hierarchy_path,
            elements=elements,
            meta={}
        )

    def wait_for_stability(self, seconds: float = 0.8) -> None:
        time.sleep(seconds)

    def perform_action(self, action: Action) -> None:
        if action.kind == "tap" and action.element_xpath:
            # Find by XPath and click
            el = self.driver.find_element("xpath", action.element_xpath)
            el.click()
        elif action.kind == "back":
            self.driver.back()
        elif action.kind == "swipe":
            direction = action.meta.get("direction", "up")
            try:
                self.driver.execute_script("mobile: swipeGesture", {"direction": direction, "percent": 0.7})
            except Exception:
                pass

    def explore(self) -> ExplorationResult:
        result = ExplorationResult()
        # DFS stack: (fingerprint, depth)
        start_capture = self.capture_screen("S-0001", depth=0)
        result.screens.append(start_capture)
        self.visited.add(start_capture.fingerprint)
        stack: List[ScreenCapture] = [start_capture]

        screen_counter = 1
        while stack and not self.budget.expired():
            current = stack.pop()
            if len(result.screens) >= self.max_screens:
                break
            if current.depth >= self.max_depth:
                continue

            used = self.used_actions.setdefault(current.fingerprint, set())
            actions = build_actions_for_screen(
                elements=current.elements,
                denylist_keywords=self.denylist,
                safe_mode=self.safe_mode,
                max_actions=self.per_screen_action_budget,
                already_used_xpaths=used
            )

            progressed = False
            for a in actions:
                if self.budget.expired():
                    break
                if a.element_xpath:
                    used.add(a.element_xpath)
                try:
                    self.perform_action(a)
                    self.wait_for_stability()
                    screen_counter += 1
                    sc_id = f"S-{screen_counter:04d}"
                    new_capture = self.capture_screen(sc_id, depth=current.depth + 1)
                    result.transitions.append(Transition(
                        from_fingerprint=current.fingerprint,
                        to_fingerprint=new_capture.fingerprint,
                        action=a
                    ))
                    if new_capture.fingerprint not in self.visited:
                        self.visited.add(new_capture.fingerprint)
                        result.screens.append(new_capture)
                        stack.append(new_capture)
                        progressed = True
                    else:
                        # attempt to go back if it didn't create a new screen
                        try:
                            self.driver.back()
                            self.wait_for_stability(0.6)
                        except Exception:
                            pass
                except Exception as e:
                    result.errors.append({"screen_id": current.screen_id, "action": a.__dict__, "error": str(e)})
                    # recover: try back
                    try:
                        self.driver.back()
                    except Exception:
                        pass
                    self.wait_for_stability(0.6)

            if not progressed and not self.budget.expired():
                # Try a swipe to discover more content on this screen (scroll)
                try:
                    self.driver.execute_script("mobile: swipeGesture", {"direction": "up", "percent": 0.7})
                    self.wait_for_stability(0.8)
                    # recapture after swipe and if new fingerprint, add to graph as same depth+1 via swipe
                    xml = self.driver.page_source
                    elements = parse_hierarchy(self.platform, xml)
                    fp2 = fingerprint_screen(self.platform, elements, xml)
                    if fp2 not in self.visited:
                        screen_counter += 1
                        sc_id = f"S-{screen_counter:04d}"
                        swipe_capture = self.capture_screen(sc_id, depth=current.depth + 1)
                        result.transitions.append(Transition(
                            from_fingerprint=current.fingerprint,
                            to_fingerprint=swipe_capture.fingerprint,
                            action=Action(action_id=f"A-SWIPE-{screen_counter:04d}", kind="swipe", meta={"direction":"up"})
                        ))
                        self.visited.add(swipe_capture.fingerprint)
                        result.screens.append(swipe_capture)
                        stack.append(swipe_capture)
                    else:
                        # go back to original position is non-trivial; keep going
                        pass
                except Exception:
                    pass

        return result
