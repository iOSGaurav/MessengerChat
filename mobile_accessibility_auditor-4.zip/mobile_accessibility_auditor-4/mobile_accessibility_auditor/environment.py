from __future__ import annotations
import json
from typing import Any, Dict, List, Optional
import httpx
from .utils.subprocesses import run_cmd
from .utils.logging import get_logger

log = get_logger(__name__)

def check_appium(server_url: str) -> Dict[str, Any]:
    try:
        with httpx.Client(timeout=4.0) as client:
            r = client.get(server_url.rstrip("/") + "/status")
            r.raise_for_status()
            data = r.json()
        return {"ok": True, "status": data}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def check_android() -> Dict[str, Any]:
    checks: Dict[str, Any] = {}
    rc, out, err = run_cmd(["adb", "version"], timeout=10)
    checks["adb"] = {"ok": rc == 0, "stdout": out.strip(), "stderr": err.strip()}
    rc, out, err = run_cmd(["adb", "devices", "-l"], timeout=10)
    checks["devices"] = {"ok": rc == 0, "stdout": out.strip(), "stderr": err.strip()}
    return checks

def check_ios() -> Dict[str, Any]:
    checks: Dict[str, Any] = {}
    rc, out, err = run_cmd(["xcode-select", "-p"], timeout=10)
    checks["xcode_select"] = {"ok": rc == 0, "stdout": out.strip(), "stderr": err.strip()}
    rc, out, err = run_cmd(["xcrun", "simctl", "list", "devices", "--json"], timeout=30)
    checks["simctl"] = {"ok": rc == 0, "stderr": err.strip()}
    if rc == 0:
        try:
            checks["simctl"]["json"] = json.loads(out)
        except Exception:
            checks["simctl"]["json"] = None
    rc, out, err = run_cmd(["xcrun", "xctrace", "list", "devices"], timeout=30)
    checks["xctrace"] = {"ok": rc == 0, "stdout": out.strip(), "stderr": err.strip()}
    return checks
