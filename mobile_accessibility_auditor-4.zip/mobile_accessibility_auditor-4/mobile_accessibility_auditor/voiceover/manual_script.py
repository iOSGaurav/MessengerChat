from __future__ import annotations
from typing import Any, Dict, List
from ..explorer.models import ScreenCapture
from .synthesis import synthesize_screen_announcements
from .rotor import rotor_presence_assertions

def generate_manual_voiceover_script(run_meta: Dict[str, Any], screens: List[ScreenCapture]) -> str:
    lines: List[str] = []
    lines.append("# Manual VoiceOver Test Script (VPAT-ready)\n")
    lines.append(f"- Tool: {run_meta.get('tool')} v{run_meta.get('version')}")
    lines.append(f"- Platform: {run_meta.get('platform')}")
    lines.append(f"- Device: {run_meta.get('device')}")
    lines.append(f"- App: {run_meta.get('app')}\n")
    lines.append("## Pre-checks")
    lines.append("1. Enable VoiceOver: Settings → Accessibility → VoiceOver → ON.")
    lines.append("2. Set Speech verbosity to default (unless testing verbosity explicitly).")
    lines.append("3. Ensure the test account is logged in (if required).\n")
    lines.append("## How to execute")
    lines.append("- For each screen below:")
    lines.append("  - Use **swipe right** to move focus through elements.")
    lines.append("  - Confirm announcements match **Expected announcements** (allowing minor OS phrasing differences).")
    lines.append("  - Use **Rotor** (rotate two fingers) to verify expected rotor categories are present.")
    lines.append("  - Confirm there is no focus trap (especially in modals).\n")
    for s in screens:
        lines.append(f"---\n## Screen {s.screen_id}")
        lines.append(f"- Fingerprint: `{s.fingerprint}`")
        lines.append(f"- Evidence: screenshot `{_rel(s.screenshot_path)}`, hierarchy `{_rel(s.hierarchy_path)}`")
        assertions = rotor_presence_assertions(s.elements)
        lines.append("### Rotor categories to verify")
        if assertions:
            for a in assertions:
                lines.append(f"- **{a['category']}** — expected (reason: {a['reason']})")
        else:
            lines.append("- No strong rotor-category expectations inferred from the accessibility tree for this screen.")
        lines.append("\n### Expected announcements (synthesized)")
        anns = synthesize_screen_announcements(s.elements, limit=40)
        if anns:
            for a in anns:
                lines.append(f"{a['index']}. {a['announcement']}  \n   - xpath: `{a['xpath']}`")
        else:
            lines.append("_No focusable candidates detected by heuristic._")
        lines.append("\n### Manual checks")
        lines.append("- Confirm all interactive controls have meaningful labels (no 'button' without context).")
        lines.append("- Confirm focus order is logical and matches reading order.")
        lines.append("- Confirm custom controls expose correct role/traits.")
        lines.append("- If modal/alert: confirm a dismiss action is reachable and announced.\n")
    return "\n".join(lines)

def _rel(path: str) -> str:
    p = path.replace('\\\\','/').split('/')
    if 'artifacts' in p:
        i = p.index('artifacts')
        return '/'.join(p[i+1:])
    return path.replace('\\\\','/')
