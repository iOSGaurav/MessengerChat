from __future__ import annotations
from typing import Any, Dict, List
from ..explorer.models import ElementInfo

def infer_rotor_categories(elements: List[ElementInfo]) -> Dict[str, Dict[str, Any]]:
    counts = {"Headings": 0, "Links": 0, "Form Controls": 0, "Buttons": 0}
    examples = {k: [] for k in counts.keys()}

    for e in elements:
        role = (e.role or "").lower()
        cn = (e.class_name or "").lower()
        traits = str(e.raw.get("traits", "")).lower()

        is_header = ("header" in traits) or ("heading" in traits) or (role == "header")
        if is_header:
            counts["Headings"] += 1
            if len(examples["Headings"]) < 5:
                examples["Headings"].append({"xpath": e.xpath, "label": e.accessible_name(), "class": e.class_name})

        is_link = ("link" in traits) or (role == "link") or ("link" in cn)
        if is_link:
            counts["Links"] += 1
            if len(examples["Links"]) < 5:
                examples["Links"].append({"xpath": e.xpath, "label": e.accessible_name(), "class": e.class_name})

        is_form = role in ("textbox","switch","checkbox") or ("textfield" in cn) or ("edittext" in cn) or ("switch" in cn) or ("checkbox" in cn)
        if is_form:
            counts["Form Controls"] += 1
            if len(examples["Form Controls"]) < 5:
                examples["Form Controls"].append({"xpath": e.xpath, "label": e.accessible_name(), "class": e.class_name})

        is_btn = role == "button" or ("button" in cn)
        if is_btn:
            counts["Buttons"] += 1
            if len(examples["Buttons"]) < 5:
                examples["Buttons"].append({"xpath": e.xpath, "label": e.accessible_name(), "class": e.class_name})

    return {k: {"count": counts[k], "examples": examples[k]} for k in counts.keys()}

def rotor_presence_assertions(elements: List[ElementInfo]) -> List[Dict[str, Any]]:
    inferred = infer_rotor_categories(elements)
    assertions: List[Dict[str, Any]] = []
    if inferred["Buttons"]["count"] > 0:
        assertions.append({"category": "Buttons", "expected": True, "reason": "Buttons detected in accessibility tree.", "examples": inferred["Buttons"]["examples"]})
    if inferred["Form Controls"]["count"] > 0:
        assertions.append({"category": "Form Controls", "expected": True, "reason": "Form controls detected in accessibility tree.", "examples": inferred["Form Controls"]["examples"]})
    if inferred["Headings"]["count"] > 0:
        assertions.append({"category": "Headings", "expected": True, "reason": "Heading-like elements detected (traits/header).", "examples": inferred["Headings"]["examples"]})
    if inferred["Links"]["count"] > 0:
        assertions.append({"category": "Links", "expected": True, "reason": "Link-like elements detected (traits/link).", "examples": inferred["Links"]["examples"]})
    return assertions
