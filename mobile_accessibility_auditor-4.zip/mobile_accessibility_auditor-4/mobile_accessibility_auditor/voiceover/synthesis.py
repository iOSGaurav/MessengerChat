from __future__ import annotations
from typing import Any, Dict, List
from ..explorer.models import ElementInfo

ROLE_SPOKEN = {
    "button": "button",
    "textbox": "text field",
    "image": "image",
    "link": "link",
    "header": "heading",
    "switch": "switch",
    "checkbox": "checkbox",
}

def _role_from_element(e: ElementInfo) -> str:
    if e.role:
        return e.role
    cn = (e.class_name or "").lower()
    if "button" in cn:
        return "button"
    if "textfield" in cn or "edittext" in cn:
        return "textbox"
    if "image" in cn or "imageview" in cn:
        return "image"
    if "switch" in cn:
        return "switch"
    if "checkbox" in cn:
        return "checkbox"
    return "element"

def synthesize_voiceover_announcement(e: ElementInfo) -> str:
    label = e.accessible_name().strip()
    role = _role_from_element(e)
    parts: List[str] = []
    if label:
        parts.append(label)
    parts.append(ROLE_SPOKEN.get(role, role))
    if e.enabled is False:
        parts.append("dimmed")
    sel = str(e.raw.get("selected", "")).lower()
    chk = str(e.raw.get("checked", "")).lower()
    if sel in ("true","1","yes"):
        parts.append("selected")
    if chk in ("true","1","yes"):
        parts.append("checked")
    return ", ".join([p for p in parts if p])

def expected_focus_order(elements: List[ElementInfo]) -> List[ElementInfo]:
    def key(e: ElementInfo):
        b = e.bounds or (10**9,10**9,10**9,10**9)
        return (b[1], b[0], b[3]-b[1], b[2]-b[0], e.xpath)

    cands: List[ElementInfo] = []
    for e in elements:
        if e.clickable is True or e.role in ("button","textbox"):
            cands.append(e)
        else:
            if (e.text or e.raw.get("label")) and e.bounds:
                cands.append(e)
    return sorted(cands, key=key)

def synthesize_screen_announcements(elements: List[ElementInfo], limit: int = 80) -> List[Dict[str, Any]]:
    ordered = expected_focus_order(elements)[:limit]
    out: List[Dict[str, Any]] = []
    for i, e in enumerate(ordered, start=1):
        out.append({
            "index": i,
            "xpath": e.xpath,
            "class": e.class_name,
            "resource_id": e.resource_id,
            "bounds": e.bounds,
            "label": e.accessible_name(),
            "announcement": synthesize_voiceover_announcement(e),
        })
    return out
