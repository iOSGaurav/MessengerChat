from __future__ import annotations
import os
import time
import json
import datetime as dt
from typing import Any, Dict, Optional, List
import yaml

from .config import RootConfig
from .drivers.factory import build_driver
from .explorer.traversal import Explorer
from .audit.engine import run_rules
from .ai.providers import build_ai_provider, maybe_redact
from .reports.html_report import render_html_report
from .reports.pdf_report import render_pdf_report
from .reports.scorecard import build_scorecard
from .utils.fs import ensure_dir, write_json
from .utils.logging import get_logger

log = get_logger(__name__)

def load_config(path: str) -> RootConfig:
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return RootConfig.model_validate(data)

def run_audit_from_config(config: RootConfig, *, interactive: bool = False) -> Dict[str, Any]:
    started = dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    ts = dt.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(config.report.output_dir, ts)
    ensure_dir(out_dir)
    ensure_dir(os.path.join(out_dir, "screens"))

    driver_impl = build_driver(config)
    session = None
    ai_provider = build_ai_provider(config.ai.model_dump())
    ai_findings: List[Dict[str, Any]] = []

    run_meta = {
        "tool": "mobile_accessibility_auditor",
        "version": "1.0.0",
        "platform": config.platform,
        "started_at": started,
        "appium_server_url": config.appium_server_url,
        "device": driver_impl.get_device_metadata(),
        "app": config.app.model_dump(),
        "ai": {"enabled": config.ai.enabled, "provider": config.ai.provider, "model": config.ai.model},
    }

    try:
        session = driver_impl.create_session()

        # Login/onboarding strategy
        if config.login.strategy == "manual":
            if interactive:
                prompt = config.login.manual_prompt or "Complete login then type READY"
                print("\n" + prompt)
                while True:
                    s = input("Type READY to continue: ").strip()
                    if s.upper() == "READY":
                        break
            else:
                # In CI, manual strategy cannot progress
                log.warning("CI mode with manual login strategy: continuing immediately. Ensure app is already authenticated.")
        elif config.login.strategy == "seed_steps":
            from .seed import run_seed_steps
            if not config.login.seed_steps_path:
                raise ValueError("login.seed_steps_path is required for seed_steps strategy")
            run_seed_steps(session, config.login.seed_steps_path)
        elif config.login.strategy == "deeplink":
            if not config.login.deeplink_url:
                raise ValueError("login.deeplink_url is required for deeplink strategy")
            driver_impl.open_deeplink(session, config.login.deeplink_url)
            time.sleep(1.0)

        # Exploration
        explorer = Explorer(
            platform=config.platform,
            driver=session,
            artifacts_dir=out_dir,
            exploration_cfg=config.exploration.model_dump(),
            safety_cfg=config.safety.model_dump(),
        )
        exp_result = explorer.explore()

        # Deterministic audits
        findings = run_rules(exp_result.screens, config.audit.model_dump())

        # Optional AI augmentations (advisory only)
        if config.ai.enabled:
            # label quality suggestions per screen
            if config.ai.features.label_quality:
                import asyncio
                async def _labels():
                    out = []
                    for s in exp_result.screens:
                        elems = [{"xpath": e.xpath, "label": e.accessible_name(), "class": e.class_name, "resource_id": e.resource_id} for e in s.elements if (e.clickable is True or e.role in ("button","textbox"))]
                        payload = maybe_redact(config.ai.model_dump(), {"elements": elems})
                        sug = await ai_provider.analyze_labels(platform=config.platform, screen_id=s.screen_id, elements=payload["elements"])
                        for item in sug:
                            out.append({"type":"label_quality","screen_id": s.screen_id, "data": item.model_dump(), "ai_assisted": True, "confidence": item.confidence})
                    return out
                ai_findings.extend(asyncio.run(_labels()))

            # remediation suggestions per finding
            if config.ai.features.remediation:
                import asyncio
                async def _remed():
                    out = []
                    for f in findings[:80]:
                        payload = maybe_redact(config.ai.model_dump(), f.__dict__)
                        rems = await ai_provider.generate_remediation(platform=config.platform, finding=payload)
                        for r in rems:
                            out.append({"type":"remediation","finding_id": f.id, "data": r.model_dump(), "ai_assisted": True, "confidence": r.confidence})
                    return out
                ai_findings.extend(asyncio.run(_remed()))

        finished = dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
        report = {
            "run": {**run_meta, "finished_at": finished},
            "screens": [
                {
                    "screen_id": s.screen_id,
                    "fingerprint": s.fingerprint,
                    "depth": s.depth,
                    "activity": s.url_or_activity,
                    "screenshot": _rel(out_dir, s.screenshot_path),
                    "hierarchy": _rel(out_dir, s.hierarchy_path),
                    "elements_count": len(s.elements),
                }
                for s in exp_result.screens
            ],
            "transitions": [
                {
                    "from": t.from_fingerprint,
                    "to": t.to_fingerprint,
                    "action": t.action.__dict__,
                }
                for t in exp_result.transitions
            ],
            "errors": exp_result.errors,
            "findings": [f.__dict__ for f in findings],
            "ai_findings": ai_findings,
        }

        # Summary
        summary = _summarize(report)
        report["summary"] = summary

        # VoiceOver suite artifacts (iOS-focused; deterministic synthesis, VPAT-ready)
        if config.platform == "ios":
            from .voiceover.synthesis import synthesize_screen_announcements
            from .voiceover.manual_script import generate_manual_voiceover_script
            from .reports.vpat_voiceover import generate_vpat_voiceover_evidence
            from .utils.fs import write_text

            vo_ann = {s.screen_id: synthesize_screen_announcements(s.elements, limit=80) for s in exp_result.screens}
            vo_ann_path = os.path.join(out_dir, "voiceover_expected_announcements.json")
            write_json(vo_ann_path, vo_ann)

            vo_script_path = os.path.join(out_dir, "voiceover_manual_test.md")
            write_text(vo_script_path, generate_manual_voiceover_script(run_meta, exp_result.screens))

            vo_vpat_path = os.path.join(out_dir, "vpat_voiceover_evidence.md")
            write_text(vo_vpat_path, generate_vpat_voiceover_evidence(run_meta, exp_result.screens))

            report["voiceover"] = {
                "expected_announcements": _rel(out_dir, vo_ann_path),
                "manual_test": _rel(out_dir, vo_script_path),
                "vpat_evidence": _rel(out_dir, vo_vpat_path),
            }
        else:
            report["voiceover"] = None

        # Write reports
        report_json_path = os.path.join(out_dir, "report.json")
        write_json(report_json_path, report)

        templates_dir = os.path.join(os.path.dirname(__file__), "reports", "templates")
        report_html_path = os.path.join(out_dir, "report.html")
        render_html_report(report, report_html_path, templates_dir=templates_dir)

        report_pdf_path = os.path.join(out_dir, "report.pdf")
        if "pdf" in (config.report.formats or []):
            render_pdf_report(report, report_pdf_path)

        scorecard = build_scorecard({"summary": summary, "findings": report["findings"]})
        scorecard_path = os.path.join(out_dir, "scorecard.json")
        write_json(scorecard_path, scorecard)

        return {
            "summary": summary,
            "report_paths": {
                "json": report_json_path,
                "html": report_html_path,
                "pdf": report_pdf_path if os.path.exists(report_pdf_path) else None,
                "scorecard": scorecard_path,
                "voiceover_expected_announcements": (report.get("voiceover") or {}).get("expected_announcements"),
                "voiceover_manual_test": (report.get("voiceover") or {}).get("manual_test"),
                "vpat_voiceover_evidence": (report.get("voiceover") or {}).get("vpat_evidence"),
            },
            "scorecard": scorecard,
            "artifacts_dir": out_dir,
        }

    finally:
        if session is not None:
            try:
                session.quit()
            except Exception:
                pass

def _summarize(report: Dict[str, Any]) -> Dict[str, Any]:
    findings = report.get("findings", [])
    by_sev = {"critical": 0, "major": 0, "minor": 0}
    by_wcag: Dict[str, int] = {}
    for f in findings:
        sev = f.get("severity", "minor")
        if sev not in by_sev:
            by_sev[sev] = 0
        by_sev[sev] += 1
        wcag = f.get("wcag", "unknown")
        by_wcag[wcag] = by_wcag.get(wcag, 0) + 1
    return {
        "screens_visited": len(report.get("screens", [])),
        "findings_total": len(findings),
        "by_severity": by_sev,
        "by_wcag": by_wcag,
        "ai_findings_total": len(report.get("ai_findings", [])),
    }

def _rel(run_dir: str, path: str) -> str:
    # Return relative path from run_dir
    try:
        return os.path.relpath(path, run_dir).replace("\\", "/")
    except Exception:
        return path.replace("\\", "/")
