from __future__ import annotations
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field

Platform = Literal["ios", "android"]

class ExplorationConfig(BaseModel):
    max_screens: int = 60
    max_depth: int = 10
    per_screen_action_budget: int = 35
    global_time_budget_minutes: int = 20

class SafetyConfig(BaseModel):
    safe_mode: bool = True
    denylist_keywords: List[str] = Field(default_factory=lambda: ["delete", "logout", "pay", "purchase", "unsubscribe"])

class ContrastConfig(BaseModel):
    enabled: bool = False

class AuditConfig(BaseModel):
    wcag_version: str = "2.2"
    levels: List[str] = Field(default_factory=lambda: ["A", "AA"])
    min_target_size: int = 44
    min_contrast_ratio: float = 4.5
    contrast: ContrastConfig = Field(default_factory=ContrastConfig)

class ReportConfig(BaseModel):
    output_dir: str = "artifacts"
    formats: List[str] = Field(default_factory=lambda: ["json", "html", "pdf"])

class AIFeatures(BaseModel):
    label_quality: bool = True
    remediation: bool = True
    focus_order: bool = True
    truncation: bool = True

class AIPrivacy(BaseModel):
    send_screenshots: bool = False
    send_full_page_source: bool = False
    redact_sensitive_text: bool = True

class AIConfig(BaseModel):
    enabled: bool = False
    provider: str = "none"   # openai | azure | ollama | none
    model: str = "gpt-4o-mini"
    timeout_seconds: int = 20
    features: AIFeatures = Field(default_factory=AIFeatures)
    privacy: AIPrivacy = Field(default_factory=AIPrivacy)

class LoginConfig(BaseModel):
    strategy: str = "manual"  # manual | seed_steps | deeplink
    manual_prompt: str = "Complete login/onboarding, then type READY here to continue."
    seed_steps_path: Optional[str] = None
    deeplink_url: Optional[str] = None

class AndroidTarget(BaseModel):
    device_udid: Optional[str] = None

class IOSTarget(BaseModel):
    udid: Optional[str] = None
    device_name: Optional[str] = None

class TargetsConfig(BaseModel):
    android: AndroidTarget = Field(default_factory=AndroidTarget)
    ios: IOSTarget = Field(default_factory=IOSTarget)

class AppConfig(BaseModel):
    method: str
    # Android
    appPackage: Optional[str] = None
    appActivity: Optional[str] = None
    apkPath: Optional[str] = None
    # iOS
    bundleId: Optional[str] = None
    appPath: Optional[str] = None
    ipaPath: Optional[str] = None

class CapabilitiesConfig(BaseModel):
    alwaysMatch: Dict[str, Any] = Field(default_factory=dict)

class RootConfig(BaseModel):
    platform: Platform
    appium_server_url: str = "http://127.0.0.1:4723"
    targets: TargetsConfig = Field(default_factory=TargetsConfig)
    app: AppConfig
    capabilities: Optional[CapabilitiesConfig] = None
    login: LoginConfig = Field(default_factory=LoginConfig)
    exploration: ExplorationConfig = Field(default_factory=ExplorationConfig)
    safety: SafetyConfig = Field(default_factory=SafetyConfig)
    audit: AuditConfig = Field(default_factory=AuditConfig)
    report: ReportConfig = Field(default_factory=ReportConfig)
    ai: AIConfig = Field(default_factory=AIConfig)
