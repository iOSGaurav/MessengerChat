# VoiceOver Suite (Announcements + Rotor + Manual Script + VPAT Evidence)

This tool does **not** toggle VoiceOver on/off or automate rotor gestures using private iOS APIs.
Instead, it provides **production-defensible** VoiceOver support via:

1. **Rotor category presence expectations** (inferred from semantic cues in the accessibility tree)
2. **Spoken string synthesis** (deterministic expected announcements from labels/roles/states)
3. **Manual VoiceOver test script generation** (step-by-step)
4. **VPAT-ready VoiceOver evidence appendix** (screenshots + hierarchy + expectations)

## Outputs (per audit run)

- `voiceover_expected_announcements.json`
- `voiceover_manual_test.md`
- `vpat_voiceover_evidence.md`

## Limitations

- Rotor category availability varies with OS context and app semantics.
- Spoken synthesis is deterministic and may differ slightly from iOS phrasing; it's intended as a baseline for manual verification.
