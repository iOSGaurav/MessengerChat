# Exploration Engine

The traversal engine builds a **screen graph** as it explores.

## Goals

- Maximize screen coverage
- Avoid loops / repeated screens
- Avoid destructive actions (safe-mode)
- Produce deterministic, repeatable runs

## Screen fingerprinting

A screen fingerprint is computed from:
- UI hierarchy (XML)
- Accessibility-relevant element attributes (type/role, id, label/text/content-desc, bounds)
- Lightweight normalization and hashing

Fingerprints are used for:
- Loop detection
- Graph edges (action transitions)

## Action selection

Candidate actions are selected from the current UI:
- Prefer clickable/tappable elements
- Filter by safe-mode denylist keywords (e.g. delete/purchase/logout)
- Avoid repeating the same action on the same screen
- Budget actions per screen (`per_screen_action_budget`)

## Navigation strategies

- Android:
  - `driver.back()` or `adb shell input keyevent 4` fallback
- iOS:
  - Try back button in navigation bar
  - Fallback: edge-swipe gesture (W3C actions)

## Scroll handling

If action budget remains and no new screens are found:
- Attempt scroll/swipe within scrollable containers
- Re-scan for new clickable elements

## Time budgets

A global time budget (`global_time_budget_minutes`) bounds the run.

The engine stops when any of:
- max screens reached
- max depth reached
- time budget exceeded
- app session fails unrecoverably

All errors are captured in the report.
