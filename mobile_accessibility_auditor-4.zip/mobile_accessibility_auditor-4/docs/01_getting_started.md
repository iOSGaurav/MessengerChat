# Getting Started

## System requirements

- Python 3.10+
- Appium 2.x (recommended)
- Node.js 18+ (for Appium)
- Android SDK (adb, emulator)
- Xcode + Xcode Command Line Tools (for iOS)

This tool is designed to run locally and in CI.

---

## Install Appium (recommended)

```bash
npm install -g appium
appium driver install uiautomator2
appium driver install xcuitest
```

Optional useful plugins:
```bash
appium plugin install --source=npm @appium/plugin-images
```

Start Appium:
```bash
appium --address 127.0.0.1 --port 4723
```

---

## Android prerequisites

- Android SDK installed and `adb` available on PATH.
- At least one device/emulator available:

```bash
adb devices
```

For emulator:
```bash
emulator -list-avds
emulator -avd <NAME>
```

---

## iOS prerequisites

- Xcode installed
- Xcode CLI tools:

```bash
xcode-select -p
xcrun simctl list devices
```

For simulators, ensure at least one booted or boot one:
```bash
xcrun simctl boot "iPhone 15"
```

For physical devices, you typically need:
- Apple developer tools setup
- iOS device paired/trusted
- Proper signing for WebDriverAgent handled by Appium XCUITest driver

---

## Install the tool

From the repository root:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
```

---

## Run an audit

Interactive:
```bash
python -m mobile_accessibility_auditor.cli
```

CI mode:
```bash
python -m mobile_accessibility_auditor.cli --config examples/config.android.yaml --ci
```

---

## Output

By default, reports are written to:
- `artifacts/<timestamp>/report.json`
- `artifacts/<timestamp>/report.html`
- `artifacts/<timestamp>/report.pdf` (if enabled)

See `docs/05_reports.md`.
