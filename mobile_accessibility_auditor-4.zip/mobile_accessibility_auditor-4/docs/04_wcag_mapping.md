# WCAG Mapping

This tool implements a deterministic rule engine mapped to WCAG 2.2 A + AA.

## Implemented rules

| Rule | WCAG | Level |
|---|---:|:---:|
| Missing accessible name for interactive controls | 4.1.2 | A |
| Incorrect role/semantics (heuristic) | 4.1.2 | A |
| Hit target < min size (default 44x44) | 2.5.8 | AA |
| Duplicate labels among controls on same screen | 2.4.6 | AA |
| Unfocusable controls (clickable but not focusable/accessible) | 2.1.1 | A |
| Modal/dialog without obvious dismiss action | 2.1.2 | A |
| Text truncation (heuristic) | 1.4.4 | AA |
| Contrast (optional screenshot heuristic) | 1.4.3 | AA |

## Evidence

Each finding includes:
- WCAG criterion
- Level
- Severity
- Screen id + screen fingerprint
- Element selector reference (xpath-ish)
- Raw element attributes
- Screenshot + hierarchy paths

## Determinism

Only the rule engine determines pass/fail.

AI is strictly advisory and is never used to decide compliance.
