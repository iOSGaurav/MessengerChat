# Reports

The tool writes reports into an `artifacts/<timestamp>` folder by default.

## Outputs

- `report.json` — full structured findings
- `report.html` — human-readable report with evidence links
- `report.pdf` — optional PDF export (if enabled)
- `scorecard.json` — aggregated counts and per-WCAG breakdown

## JSON schema (high level)

- `run`: metadata (time, platform, device, app info)
- `screens`: list of discovered screens (fingerprints, actions, evidence paths)
- `findings`: list of findings (rule-based)
- `ai_findings`: list of AI-assisted suggestions (if enabled)
- `summary`: counts + coverage metrics

## HTML

The HTML report:
- provides a WCAG breakdown
- includes screen-wise findings
- links to screenshots and XML hierarchy files

## PDF

PDF is generated from the same data using `reportlab`.
