# AI Mode (Optional)

AI is **OFF by default**.

## Goals

AI is used only to:
- improve label quality analysis
- generate remediation suggestions
- explain heuristics (truncation/contrast)
- optionally score navigation risk (advisor only)

## Privacy controls

AI mode supports redaction:
- by default screenshots are NOT sent
- by default full page source is NOT sent
- sensitive-looking text is redacted before sending

## Providers

- `none` (default)
- `openai`
- `azure`
- `ollama`

Configure in YAML:

```yaml
ai:
  enabled: false
  provider: openai
  model: gpt-4o-mini
  timeout_seconds: 20
  features:
    label_quality: true
    remediation: true
    focus_order: true
    truncation: true
  privacy:
    send_screenshots: false
    send_full_page_source: false
    redact_sensitive_text: true
```

## Contract

Providers implement:

- `analyze_labels(...)`
- `generate_remediation(...)`
- `analyze_focus_order(...)`

All provider outputs must be strict JSON validated by Pydantic.

AI output is stored under `ai_findings` and clearly marked `ai_assisted: true`.
