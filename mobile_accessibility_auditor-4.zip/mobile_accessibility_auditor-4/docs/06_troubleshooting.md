# Troubleshooting

## Appium not reachable

- Start Appium on the configured host/port:
  ```bash
  appium --address 127.0.0.1 --port 4723
  ```
- Verify:
  ```bash
  curl http://127.0.0.1:4723/status
  ```

## Android: device not found

- Verify adb:
  ```bash
  adb version
  adb devices -l
  ```
- Ensure emulator/device is online (state `device`).

## iOS: simctl issues

- Ensure Xcode CLI tools:
  ```bash
  xcode-select -p
  xcrun simctl list devices
  ```
- Boot simulator:
  ```bash
  xcrun simctl boot "iPhone 15"
  ```

## iOS: WebDriverAgent build/signing

- With Appium XCUITest driver, WDA is typically handled automatically.
- If you see signing errors, configure:
  - `xcodeOrgId`
  - `xcodeSigningId`
  - `updatedWDABundleId`
  in capabilities.

## CI tips

- Use dedicated emulators/simulators
- Pre-install apps when possible (avoid flaky installs)
- Limit exploration for stability:
  - fewer screens
  - fewer actions per screen
  - shorter time budget
