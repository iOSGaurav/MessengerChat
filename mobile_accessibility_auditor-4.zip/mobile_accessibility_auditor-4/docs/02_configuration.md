# Configuration

The tool can run using a YAML config (`config.yaml`) and/or CLI overrides.

## Example

See:
- `examples/config.android.yaml`
- `examples/config.ios.yaml`

## Top-level fields

- `platform`: `ios` or `android`
- `appium_server_url`: e.g. `http://127.0.0.1:4723`
- `targets`: device selection (optional in interactive mode)
- `app`: launch configuration (platform-specific)
- `exploration`: traversal limits
- `safety`: safe mode + denylist keywords
- `audit`: WCAG options
- `report`: report formats and output directory
- `ai`: AI assistance config (optional)

## App configuration

### Android

```yaml
app:
  method: package_activity | apk
  appPackage: com.example
  appActivity: com.example.MainActivity
  apkPath: /path/to/app.apk
```

### iOS

```yaml
app:
  method: bundleId | app | ipa
  bundleId: com.example.ios
  appPath: /path/to/MyApp.app
  ipaPath: /path/to/MyApp.ipa
```

## Capabilities

You can supply raw capabilities:

```yaml
capabilities:
  alwaysMatch:
    platformName: Android
    appium:automationName: UiAutomator2
    appium:deviceName: emulator-5554
```

If omitted, the tool builds a safe default set from `targets` + `app`.

## Login / onboarding strategy

```yaml
login:
  strategy: manual | seed_steps | deeplink
  manual_prompt: "Complete onboarding then type READY"
  seed_steps_path: examples/seed_steps.json
  deeplink_url: "myapp://login?token=..."
```

Seed steps format is documented in `examples/seed_steps.json`.

## CI mode

Run with `--ci` to disable interactive prompts and fail fast.

See `docs/06_troubleshooting.md` for common CI issues.
